<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	 <link rel="icon" href="images/main_logo.png">
	<link rel="stylesheet" href="Admin-Dashboard.css">
	<link rel="icon" href="images/adminLogin.png">
	<title>Admin-Dashboard</title>
</head>
<body>


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<i></i>
			<span class="text">Welcome Admin</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="Admin-Dashboard.html">
					<!-- <i class='bx bxs-dashboard' ></i> -->
					<span class="text">Dashboard</span>
				</a>
			</li>

			<li>
				<a href="#">
					<!-- <i class='bx bxs-group' ></i> -->
					<span class="text">Employees</span>
				</a>
			</li>

			<li>
				<a href="#">
					<!-- <i class='bx bxs-group' ></i> -->
					<span class="text">Departments</span>
				</a>
			</li>

			<li>
				<a href="#">
					<!-- <i class='bx bxs-group' ></i> -->
					<span class="text">Attendance</span>
				</a>
			</li>

			<li>
				<a href="#">
					<!-- <i class='bx bxs-group' ></i> -->
					<span class="text">Payroll</span>
				</a>
			</li>

			<li>
				<a href="#">
					<!-- <i class='bx bxs-group' ></i> -->
					<span class="text">Leave</span>
				</a>
			</li>

			<li>
				<a href="#">
					<!-- <i class='bx bxs-group' ></i> -->
					<span class="text">Evaluation</span>
				</a>
			</li>
			
			
		</ul>
		<ul class="side-menu">
			<li>
				<a href="#">
					<i class='bx bxs-cog' ></i>
					<span class="text">Settings</span>
				</a>
			</li>
			<li>
				<a href="Admin login.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<a href="#" class="nav-link"></a>
			<form action="#">
				<div class="form-input">
					<input type="search" placeholder="Search...">
					<button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
				</div>
			</form>
			<input type="checkbox" id="switch-mode" hidden>
			<label for="switch-mode" class="switch-mode"></label>
			<a href="#" class="notification">
				<i class='bx bxs-bell' ></i>
				<span class="num">8</span>
			</a>
			<a href="#" class="profile">
				<img src="img/people.png">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Dashboard</h1>
					<ul class="breadcrumb">
						<li>
							<a href="#">Admin</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="#">Home</a>
						</li>
					</ul>
				</div>
				
			</div>

			<ul class="box-info">
				<li>
					<i class='bx bxs-calendar-check' ></i>
					<span class="text">
						<h3>1020</h3>
						<p>Total Drivers</p>
					</span>
				</li>
				<li>
					<i class='bx bxs-group' ></i>
					<span class="text">
						<h3>2834</h3>
						<p>Number of Cars</p>
					</span>
				</li>
				
			</ul>


			<div class="table-data">
				<div class="order">
					<div class="head">
						<h3>Recent Orders</h3>
						<i class='bx bx-search' ></i>
						<i class='bx bx-filter' ></i>
					</div>
					<table>
						<thead>
							<tr>
								<th>Driver</th>
								<th>Date Order</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>
									<img src="img/people.png">
									<p>Junior Kobby</p>
								</td>
								<td>05-02-2024</td>
								<td><span class="status completed">Completed</span></td>
							</tr>
							<tr>
								<td>
									<img src="img/a.jpg">
									<p>Emerald</p>
								</td>
								<td>08-02-2024</td>
								<td><span class="status pending">Completed</span></td>
							</tr>
							<tr>
								<td>
									<img src="img/b.jpg">
									<p>Marvellous B</p>
								</td>
								<td>12-02-2024</td>
								<td><span class="status process">Completed</span></td>
							</tr>
							<tr>
								<td>
									<img src="img/c.jpg">
									<p>Sandra K</p>
								</td>
								<td>16-02-2024</td>
								<td><span class="status pending">Completed</span></td>
							</tr>
							<tr>
								<td>
									<img src="img/d.jpg">
									<p>David Ofori</p>
								</td>
								<td>22-02-2024</td>
								<td><span class="status completed">Completed</span></td>
							</tr>
						</tbody>
					</table>
				</div>
				<div class="todo">
					<div class="head">
						<h3>Messages</h3>
						<i class='bx bx-plus' ></i>
						<i class='bx bx-filter' ></i>
					</div>
					<ul class="todo-list">
						<li class="completed">
							<p>Dear Admin, Kweku Kyere has completed his ride.</p>
							<i class='bx bx-dots-vertical-rounded' ></i>
						</li>
						<li class="completed">
							<p>Dear Admin, 20 staffs booked Jeffs bus. </p>
							
							<i class='bx bx-dots-vertical-rounded' ></i>
						</li>
						<li class="not-completed">
							<p>Dear Admin, Mary Quaye  requested to be a driver.</p>
							<i class='bx bx-dots-vertical-rounded' ></i>
						</li>
						<li class="completed">
							<p>Dear Admin, Kweku Dua requested to be a driver.</p>
							<i class='bx bx-dots-vertical-rounded' ></i>
						</li>
						<li class="not-completed">
							<p>Dear Admin, Benjamin just closed from work.</p>
							<i class='bx bx-dots-vertical-rounded' ></i>
						</li>
					</ul>
				</div>
			</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="Admin-Dashboard.js"></script>
</body>
</html>