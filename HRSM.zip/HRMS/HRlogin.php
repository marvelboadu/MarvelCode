<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Admin Login</title>
    <link rel="stylesheet"  href="style.css">
</head>
<body>
    <main>

        
            <!-----HEADER START-->
           <header class="header">
              <nav class="nav">
                <a href="#" class="nav_logo"><span>Group 1 </span>HR_SYSTEM</a>
    
                <ul class="nav_items">
                    <li class="nav_items">
                        <a href="index.php" class="nav_link">Home</a>
                        <a href="#" class="nav_link">-</a>
                        <a href="#footer" class="nav_link">Contact</a> 
                        
                    </li>
                </ul>
                <div class="dropdown">
  <button id="loginBtn" class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
    LOGIN
  </button>
  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="Admin login.php">Administrator</a></li>
    <li><a class="dropdown-item" href="EmployeeLogin.php">Employee</a></li>
    <li><a class="dropdown-item" href="index.php">Guest</a></li>
   
  </ul>
</div>
              </nav>
              
            
                
               
             

           


              </header>
               <!----HEADER END-->

             

               <!---Home-->
  
                <div class="home">
                    <div class="txt" id="txtMn">
                        <p  class="main">WELCOME TO OUR HR PLATFORM</p>

                        <p class="preTxt">
    Manage employee records, track attendance, 
    handle payroll,and oversee training and 
    evaluations—all in one place. 
    Enhance efficiency and ensure seamless HR 
    operations with 
    our user-friendly and powerful platform.
                        </p>
                    </div>

                    <div class="signUpForm" id="signUpForm">
                    <form >
               <div class="signForm">
               <h2>HR Manager</h2>
                <div class="input_box">
                    
                   
                    <input class="inputs" type="email" id="email" placeholder="Enter Your Email " required />

                    <input class="inputs" type="password" id="password" placeholder="Enter Your Password" required />
                        
                 
                    
                    <div class="option_field">
                        <span class="checkbox">
                            <input type="checkbox" id="check">
                            <label for="check">Remember Me</label>

                        </span>
                        <a href="#" class="forgot_pw">Forgot Password?</a>
                    </div>
                    
                   
                <button class="button" type="submit"  formaction="HRdashboard.php" >Login</button>
                    
                    </div>


                    <div class="login_signup">
                        Don't Have An Account? <a href="index.php" id="signup">SignUp</a>
                    </div>
               </div>
                </form>
                    </div>

                   
            </div>


              
                    
                    
                                   
          




           
            <!--Boostrap card link-->

                

            <!--Boostrap card link-->

                <!--Reviews and footer-->

                <div class="footer" id="footer">
                    <p class="footer-text">Follor us for more info:</p>

                    <div class="socialHandles">
                     
                        <a href="#"><i class="fa-brands fa-facebook"></i></a> 
                        <a href="#"><i class="fa-brands fa-instagram"></i></a> 
                        <a href="#"><i class="fa-brands fa-twitter"></i></a> 
                        <a href="#"><i class="fa-brands fa-google-plus"></i></a> 

                        <a href=""><i class="fa-brands fa-youtube"></i></a>     


                   



                </div>
            </div>
            <div class="footer-bottom">
                <p>Copyright &#169; 2024; Designed by <span>Group1</span></p>
            </div>





                <script src="js.js"></script>
            </main>
</body>
</html>