// // Wait for the DOM content to be fully loaded before executing the script
// document.addEventListener("DOMContentLoaded", function () {

//     // Get the form container element by its ID ("signupForm")
//     const formContainer = document.getElementById("signupForm");

//     // Get the form open button element by its ID ("form-open")
//     const formOpenButton = document.getElementById("form-open");

//     // Add a click event listener to the form open button
//     formOpenButton.addEventListener("click", function () {
        
//         // Call the toggleForm function when the button is clicked
//         toggleForm();
//     });

//     // Define the toggleForm function
//     function toggleForm() {
        
//         // Toggle the "show" class on the form container, controlling its visibility
//         formContainer.classList.toggle("show");

//         // Toggle the "overflow-hidden" class on the body, hiding the scrollbar when the form is open
//         document.body.classList.toggle("overflow-hidden");
//     }
// });

// function checkPasswordMatch() {
//     var password = document.getElementById("password").value;
//     var confirmPassword = document.getElementById("confirmPassword").value;

//     if (password === confirmPassword) {
       
//     } else {
//         alert("Passwords do not match. Please try again.");
//         return false;
//     }
// }

// //function for checkbox
// document.getElementById("sign").onclick = function(){
//     let checkbx = document.getElementById("check");
//     if(checkbx.checked){
        
//     }
//     else{
//         alert("Check to complete sign up");
//         return false;
//     }
// }