var Password = "1234"
var mail = "group1@gmail.com"

function passcheck(){

    if(document.getElementById('password').value != Password){
        alert('Wrong email or password please try again.');
        return false;
    }

    if(document.getElementById('password').value == Password){
     
       
    }

if(document.getElementById('username').value != mail){
    alert('Wrong email or password please try again.');
    return false;
}

if(document.getElementById('password').value == mail){
   
   
}
}
