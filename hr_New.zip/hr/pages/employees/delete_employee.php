<?php
include '../../includes/db_connect.php';

if (isset($_GET['id'])) {
    $employee_id = $_GET['id'];

    try {
        $stmt = $conn->prepare("DELETE FROM employee WHERE employee_id = :employee_id");
        $stmt->bindParam(':employee_id', $employee_id);
        $stmt->execute();

        header("Location: list_employees.php");
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

    $conn = null; // Close the connection
} else {
    echo "Invalid request";
    exit();
}
?>
