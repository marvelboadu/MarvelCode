<?php
include '../../includes/db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Prepare and bind
        $stmt = $conn->prepare("UPDATE employee SET employee_name = :employee_name, employee_email = :employee_email, employee_password = :employee_password, employee_address = :employee_address, employee_mobile = :employee_mobile WHERE employee_id = :employee_id");
        $stmt->bindParam(':employee_name', $employee_name);
        $stmt->bindParam(':employee_email', $employee_email);
        $stmt->bindParam(':employee_password', $employee_password);
        $stmt->bindParam(':employee_address', $employee_address);
        $stmt->bindParam(':employee_mobile', $employee_mobile);
        $stmt->bindParam(':employee_id', $employee_id);

        // Set parameters and execute
        $employee_id = $_POST['employee_id'];
        $employee_name = $_POST['employee_name'];
        $employee_email = $_POST['employee_email'];
        $employee_password = $_POST['employee_password'];
        $employee_address = $_POST['employee_address'];
        $employee_mobile = $_POST['employee_mobile'];

        $stmt->execute();

        header("Location: list_employees.php");
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

    $conn = null; // Close the connection
}
?>
