<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Evaluation - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-12">
            <h4>Add New Evaluation</h4>
            <a href="list_evaluations.php" class="btn btn-secondary mb-3">Back to Evaluations List</a>
            <form action="insert_evaluation.php" method="post">
                <div class="form-group">
                    <label for="employee_id">Employee ID</label>
                    <input type="number" class="form-control" id="employee_id" name="employee_id" required>
                </div>
                <div class="form-group">
                    <label for="eval_valuenotes">Comments</label>
                    <textarea class="form-control" id="eval_valuenotes" name="eval_valuenotes" required></textarea>
                </div>
                <button type="submit" class="btn btn-success">Add Evaluation</button>
            </form>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
