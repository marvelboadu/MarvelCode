<?php
include '../../includes/db_connect.php';

try {
    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO evaluation (employee_id, eval_valuenotes) VALUES (:employee_id, :eval_valuenotes)");
    $stmt->bindParam(':employee_id', $employee_id);
    $stmt->bindParam(':eval_valuenotes', $eval_valuenotes);

    // Set parameters and execute
    $employee_id = $_POST['employee_id'];
    $eval_valuenotes = $_POST['eval_valuenotes'];

    $stmt->execute();

    header("Location: list_evaluations.php");
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$conn = null; // Close the connection
?>
