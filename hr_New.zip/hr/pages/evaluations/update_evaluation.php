<?php
include '../../includes/db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Prepare and bind parameters
        $stmt = $conn->prepare("UPDATE evaluation SET employee_id = :employee_id, eval_valuenotes = :eval_valuenotes WHERE eval_id = :eval_id");
        $stmt->bindParam(':employee_id', $employee_id);
        $stmt->bindParam(':eval_valuenotes', $eval_valuenotes);
        $stmt->bindParam(':eval_id', $eval_id);

        // Set parameters from POST data
        $eval_id = $_POST['eval_id'];
        $employee_id = $_POST['employee_id'];
        $eval_valuenotes = $_POST['eval_valuenotes'];

        // Execute the update statement
        $stmt->execute();

        // Redirect to the list_evaluations.php after successful update
        header("Location: list_evaluations.php");
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

    // Close the connection
    $conn = null;
} else {
    echo "Invalid request";
    exit();
}
?>
