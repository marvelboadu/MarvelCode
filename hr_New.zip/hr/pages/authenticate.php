<?php
include '../includes/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare the statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM admin WHERE admin_email = :email AND admin_password = :password");
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password', $password);
    
    // Execute the statement
    $stmt->execute();
    
    // Get the result
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if a row is returned
    if ($result) {
        session_start();
        $_SESSION['user'] = $email;
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Invalid login credentials";
    }
    
    // Close the connection
    $conn = null;
}
?>
