<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Leave Application - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-6 offset-md-3">
            <h4>Add New Leave Application</h4>
            <form action="insert_leave_application.php" method="POST">
                <div class="form-group">
                    <label for="employee_id">Employee ID</label>
                    <input type="text" class="form-control" id="employee_id" name="employee_id" required>
                </div>
                <div class="form-group">
                    <label for="leave_from_date">From Date</label>
                    <input type="date" class="form-control" id="leave_from_date" name="leave_from_date" required>
                </div>
                <div class="form-group">
                    <label for="leave_to_date">To Date</label>
                    <input type="date" class="form-control" id="leave_to_date" name="leave_to_date" required>
                </div>
                <div class="form-group">
                    <label for="leave_type">Type</label>
                    <input type="text" class="form-control" id="leave_type" name="leave_type" required>
                </div>
                <div class="form-group">
                    <label for="leave_status">Status</label>
                    <input type="text" class="form-control" id="leave_status" name="leave_status" required>
                </div>
                <button type="submit" class="btn btn-success">Submit</button>
                <a href="list_leave_applications.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
