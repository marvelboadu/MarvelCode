<?php
include '../../includes/db_connect.php';

try {
    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO departments (department_name, department_description) VALUES (:department_name, :department_description)");
    $stmt->bindParam(':department_name', $department_name);
    $stmt->bindParam(':department_description', $department_description);

    // Set parameters and execute
    $department_name = $_POST['department_name'];
    $department_description = $_POST['department_description'];

    $stmt->execute();

    header("Location: list_departments.php");
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$conn = null; // Close the connection
?>
