<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}
include '../../includes/db_connect.php';

if (isset($_GET['id'])) {
    $department_id = $_GET['id'];

    // Fetch department details
    $stmt = $conn->prepare("SELECT * FROM departments WHERE department_id = :department_id");
    $stmt->bindParam(':department_id', $department_id);
    $stmt->execute();
    $department = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$department) {
        echo "Department record not found";
        exit();
    }
} else {
    echo "Invalid request";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Department - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-12">
            <h4>Edit Department</h4>
            <a href="list_departments.php" class="btn btn-secondary mb-3">Back to Department List</a>
            <form action="update_department.php" method="post">
                <input type="hidden" name="department_id" value="<?php echo $department['department_id']; ?>">
                <div class="form-group">
                    <label for="department_name">Name</label>
                    <input type="text" class="form-control" id="department_name" name="department_name" value="<?php echo $department['department_name']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="department_description">Description</label>
                    <textarea class="form-control" id="department_description" name="department_description" required><?php echo $department['department_description']; ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Update Department</button>
            </form>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
