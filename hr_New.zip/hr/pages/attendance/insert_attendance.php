<?php
include '../../includes/db_connect.php';

try {
    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO attendance (attendance_employee_id, attendance_date, status) VALUES (:attendance_employee_id, :attendance_date, :status)");
    $stmt->bindParam(':attendance_employee_id', $attendance_employee_id);
    $stmt->bindParam(':attendance_date', $attendance_date);
    $stmt->bindParam(':status', $status);

    // Set parameters and execute
    $attendance_employee_id = $_POST['attendance_employee_id'];
    $attendance_date = $_POST['attendance_date'];
    $status = $_POST['status'];

    $stmt->execute();

    header("Location: list_attendance.php");
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$conn = null; // Close the connection
?>
