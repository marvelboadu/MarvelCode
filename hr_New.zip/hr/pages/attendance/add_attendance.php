<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Attendance - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-12">
            <h4>Add New Attendance</h4>
            <a href="list_attendance.php" class="btn btn-secondary mb-3">Back to Attendance List</a>
            <form action="insert_attendance.php" method="post">
                <div class="form-group">
                    <label for="attendance_employee_id">Employee ID</label>
                    <input type="text" class="form-control" id="attendance_employee_id" name="attendance_employee_id" required>
                </div>
                <div class="form-group">
                    <label for="attendance_date">Date</label>
                    <input type="date" class="form-control" id="attendance_date" name="attendance_date" required>
                </div>
                <div class="form-group">
                    <label for="status">Status</label>
                    <select class="form-control" id="status" name="status" required>
                        <option value="Present">Present</option>
                        <option value="Absent">Absent</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-success">Add Attendance</button>
            </form>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
