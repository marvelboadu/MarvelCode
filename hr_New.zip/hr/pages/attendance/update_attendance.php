<?php
include '../../includes/db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Prepare and bind
        $stmt = $conn->prepare("UPDATE attendance SET attendance_employee_id = :attendance_employee_id, attendance_date = :attendance_date, status = :status WHERE attendance_id = :attendance_id");
        $stmt->bindParam(':attendance_employee_id', $attendance_employee_id);
        $stmt->bindParam(':attendance_date', $attendance_date);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':attendance_id', $attendance_id);

        // Set parameters and execute
        $attendance_id = $_POST['attendance_id'];
        $attendance_employee_id = $_POST['attendance_employee_id'];
        $attendance_date = $_POST['attendance_date'];
        $status = $_POST['status'];

        $stmt->execute();

        header("Location: list_attendance.php");
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

    $conn = null; // Close the connection
}
?>
