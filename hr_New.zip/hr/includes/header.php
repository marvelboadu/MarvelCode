<?php
include 'config.php';
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="/hr/index.php">HRMS - <span style="font-size: 18px;">Home</span></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav mr-auto">
            <!-- Add any additional links here -->
        </ul>
        <ul class="navbar-nav">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Login
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="<?php echo BASE_URL; ?>pages/login.php">Admin Login</a>
                    <a class="dropdown-item" href="<?php echo BASE_URL; ?>HR_Page/hr_login.php">HR Login</a>
                    <a class="dropdown-item" href="<?php echo BASE_URL; ?>Employee/employee_login.php">Employee Login</a>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo BASE_URL; ?>pages/signup.php">Sign Up</a>
            </li>
        </ul>
    </div>
</nav>
