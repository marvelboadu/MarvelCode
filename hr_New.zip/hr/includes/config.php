<?php
// Define the base URL of your project
define('BASE_URL', 'http://localhost/hr/');
?>
