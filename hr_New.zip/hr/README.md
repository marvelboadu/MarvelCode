# hrm
logins

Admin logins
email: john.doe@example.com
pass: password123



hr login
email : jane.smith@example.com
pass: password456
 

employee login:
email: bob@gmail.com
pass: bob123

Please check and upload the slq file in the db
you can also implement your own user interface for the homeScreen and also the index.php 