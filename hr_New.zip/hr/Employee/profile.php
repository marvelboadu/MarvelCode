<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: employee_login.php');
    exit();
}

// Fetch user data from session
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];
$user_email = $_SESSION['user_email'];
$employee_address = isset($_SESSION['employee_address']) ? $_SESSION['employee_address'] : '';
$employee_mobile = isset($_SESSION['employee_mobile']) ? $_SESSION['employee_mobile'] : '';

// Include database connection file
require_once '../includes/db_connect.php';

// Function to fetch attendance data
function fetchAttendanceData($db_conn, $employee_id) {
    $query = "SELECT MONTH(attendance_date) AS month, COUNT(*) AS days_present 
              FROM attendance 
              WHERE attendance_employee_id = :employee_id 
              GROUP BY MONTH(attendance_date)";
    $stmt = $db_conn->prepare($query);
    $stmt->bindParam(':employee_id', $employee_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to fetch salary data
function fetchSalaryData($db_conn, $employee_id) {
    $query = "SELECT DATE_FORMAT(month, '%M %Y') AS month, amount 
              FROM salaries 
              WHERE employee_id = :employee_id";
    $stmt = $db_conn->prepare($query);
    $stmt->bindParam(':employee_id', $employee_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to fetch training data
function fetchTrainingData($db_conn, $employee_id) {
    $query = "SELECT training_name, COUNT(*) AS training_count 
              FROM trainings 
              WHERE training_employee_id = :employee_id 
              GROUP BY training_name";
    $stmt = $db_conn->prepare($query);
    $stmt->bindParam(':employee_id', $employee_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to fetch vacation data
function fetchVacationData($db_conn, $employee_id) {
    $query = "SELECT vacation_type, DATEDIFF(vacation_to_date, vacation_from_date) AS vacation_days 
              FROM vacations 
              WHERE vacation_employee_id = :employee_id";
    $stmt = $db_conn->prepare($query);
    $stmt->bindParam(':employee_id', $employee_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Establish database connection (replace with your database credentials)
$db_conn = new PDO('mysql:host=localhost;dbname=hr', 'root', '');

// Fetch data
$attendance_data = fetchAttendanceData($db_conn, $user_id);
$salary_data = fetchSalaryData($db_conn, $user_id);
$training_data = fetchTrainingData($db_conn, $user_id);
$vacation_data = fetchVacationData($db_conn, $user_id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
        }
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #343a40;
            padding-top: 20px;
        }
        .sidebar a {
            padding: 15px;
            text-decoration: none;
            font-size: 18px;
            color: white;
            display: block;
        }
        .sidebar a:hover {
            background-color: #575d63;
        }
        .content {
            margin-left: 260px;
            padding: 20px;
        }
        .card {
            margin-bottom: 20px;
        }
        .small-chart {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
        <a href="attendance.php"><i class="fas fa-calendar-check"></i> Attendance</a>
        <a href="salaries.php"><i class="fas fa-dollar-sign"></i> Salaries</a>
        <a href="trainings.php"><i class="fas fa-chalkboard-teacher"></i> Trainings</a>
        <a href="vacations.php"><i class="fas fa-plane"></i> Vacations</a>
        <a href="evaluations.php"><i class="fas fa-star"></i> Evaluations</a>
        <a href="../pages/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h5>Personal Information</h5>
                        </div>
                        <div class="card-body">
                            <p><strong>Name:</strong> <?php echo htmlspecialchars($user_name); ?></p>
                            <p><strong>Email:</strong> <?php echo htmlspecialchars($user_email); ?></p>
                            <p><strong>Address:</strong> <?php echo htmlspecialchars($employee_address); ?> <a href="edit_address.php">Edit</a></p>
                            <p><strong>Mobile:</strong> <?php echo htmlspecialchars($employee_mobile); ?> <a href="edit_mobile.php">Edit</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h5>Attendance</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="attendanceChart" class="small-chart"></canvas>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <h5>Salaries</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="salaryChart" class="small-chart"></canvas>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <h5>Trainings</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="trainingChart" class="small-chart"></canvas>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <h5>Vacations</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="vacationChart" class="small-chart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Chart initialization code here (same as before)
    </script>
</body>
</html>
