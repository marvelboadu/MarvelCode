<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: employee_login.php');
    exit();
}

// Include database connection file
require_once '../includes/db_connect.php';

// Fetch user ID from session
$user_id = $_SESSION['user_id'];

// Fetch attendance data
$query = "SELECT MONTH(attendance_date) AS month, COUNT(*) AS days_present 
          FROM attendance 
          WHERE attendance_employee_id = :employee_id 
          GROUP BY MONTH(attendance_date)";
$stmt = $conn->prepare($query);
$stmt->bindParam(':employee_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$attendance_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        /* Add custom styles here */
    </style>
</head>
<body>
    <div class="container">
        <h1>Attendance</h1>
        <a href="profile.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        <div class="row">
            <div class="col-md-6">
                <canvas id="attendanceChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        var ctx = document.getElementById('attendanceChart').getContext('2d');
        var attendanceChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column($attendance_data, 'month')); ?>,
                datasets: [{
                    label: 'Days Present',
                    data: <?php echo json_encode(array_column($attendance_data, 'days_present')); ?>,
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
