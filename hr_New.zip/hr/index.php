<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HRMS Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 100px;
        }
        .navbar-brand span {
            font-weight: bold;
            color: #9e54ff;
        }
        .footer {
            position: absolute;
            bottom: 0;
            width: 100%;
        }
        .socialHandles a {
            font-size: 1.5rem;
            transition: color 0.3s;
        }
        .socialHandles a:hover {
            color: #9e54ff;
        }
    </style>
</head>
<body>
   <?php  include './includes/header.php'    ?>


    <div class="container text-center">
        <h1 class="display-4">Welcome to HRMS</h1>
        <p class="lead">Manage your human resources efficiently.</p>
        <p class="lead">
        Manage employee records, track attendance, 
    handle payroll,and oversee training and 
    evaluations—all in one place. 
    Enhance efficiency and ensure seamless HR 
    operations with 
    our user-friendly and powerful platform.
        </p>
       

    </div>
    <?php include 'includes/footer.php'; ?>

    <!-- Bootstrap JS and jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>
</body>
</html>
