<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Member</title>
    <!-- Bootstrap CSS link -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h2>Add New Member</h2>
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
            <div class="form-group">
                <label for="employee_id">Select Employee:</label>
                <select class="form-control" id="employee_id" name="employee_id">
                    <?php
                    // Include the database connection
                    include '../includes/db_connect.php';

                    // Query to fetch employees
                    $sql = "SELECT employee_id, employee_name FROM employee";
                    $result = $conn->query($sql);
                    
                    if ($result->rowCount() > 0) {
                        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                            echo "<option value='{$row['employee_id']}'>{$row['employee_name']}</option>";
                        }
                    }
                    ?>
                </select>
            </div>
            
            <!-- Department assignment -->
            <div class="form-group">
                <label for="department_id">Assign Department:</label>
                <select class="form-control" id="department_id" name="department_id">
                    <?php
                    // Query to fetch departments
                    $sql = "SELECT department_id, department_name FROM departments";
                    $result = $conn->query($sql);
                    
                    if ($result->rowCount() > 0) {
                        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                            echo "<option value='{$row['department_id']}'>{$row['department_name']}</option>";
                        }
                    }
                    ?>
                </select>
            </div>
            
            <!-- Training assignment -->
            <div class="form-group">
                <label for="training_id">Assign Training:</label>
                <select class="form-control" id="training_id" name="training_id">
                    <?php
                    // Query to fetch trainings
                    $sql = "SELECT training_id, training_name FROM trainings";
                    $result = $conn->query($sql);
                    
                    if ($result->rowCount() > 0) {
                        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                            echo "<option value='{$row['training_id']}'>{$row['training_name']}</option>";
                        }
                    }
                    ?>
                </select>
            </div>
            
            <!-- Leave assignment -->
            <div class="form-group">
                <label for="leave_id">Assign Leave:</label>
                <select class="form-control" id="leave_id" name="leave_id">
                    <?php
                    // Query to fetch leave types
                    $sql = "SELECT leave_id, leave_type FROM leave_applications";
                    $result = $conn->query($sql);
                    
                    if ($result->rowCount() > 0) {
                        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                            echo "<option value='{$row['leave_id']}'>{$row['leave_type']}</option>";
                        }
                    }
                    ?>
                </select>
            </div>
            
            <!-- Salary assignment (dummy placeholder, adjust as per your application logic) -->
            <div class="form-group">
                <label for="amount">Assign Salary:</label>
                <input type="text" class="form-control" id="amount" name="amount" placeholder="Enter amount">
            </div>
            
            <!-- Attendance assignment (dummy placeholder, adjust as per your application logic) -->
            <div class="form-group">
                <label for="status">Assign Attendance:</label>
                <input type="text" class="form-control" id="status" name="status" placeholder="Enter status">
            </div>
            
            <!-- Evaluation assignment (dummy placeholder, adjust as per your application logic) -->
            <div class="form-group">
                <label for="eval_valuenotes">Assign Evaluation:</label>
                <textarea class="form-control" id="eval_valuenotes" name="eval_valuenotes" rows="3"></textarea>
            </div>
            
            <!-- Vacation assignment -->
            <div class="form-group">
                <label for="vacation_id">Assign Vacation:</label>
                <select class="form-control" id="vacation_id" name="vacation_id">
                    <?php
                    // Query to fetch vacation types
                    $sql = "SELECT vacation_id, vacation_type FROM vacations";
                    $result = $conn->query($sql);
                    
                    if ($result->rowCount() > 0) {
                        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                            echo "<option value='{$row['vacation_id']}'>{$row['vacation_type']}</option>";
                        }
                    }
                    ?>
                </select>
            </div>
            
            <button type="submit" class="btn btn-primary" name="submit">Assign Details</button>
            <a href="dashboard_hr.php" class="btn btn-secondary mt-3">Back to Home</a>
        </form>
       
    </div>

    <!-- Bootstrap JS links for dropdown functionality -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
