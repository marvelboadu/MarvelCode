<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../hr_login.php");
    exit();
}

include '../../includes/db_connect.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: list_vacations.php");
    exit();
}

$vacation_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);

if ($vacation_id === false || $vacation_id === null) {
    header("Location: list_vacations.php");
    exit();
}

$sqlDelete = "DELETE FROM vacations WHERE vacation_id = :vacation_id";
$stmtDelete = $conn->prepare($sqlDelete);
$stmtDelete->bindParam(':vacation_id', $vacation_id);

if ($stmtDelete->execute()) {
    header("Location: list_vacations.php");
    exit();
} else {
    echo "Error deleting vacation: " . $stmtDelete->errorInfo()[2];
}
?>
