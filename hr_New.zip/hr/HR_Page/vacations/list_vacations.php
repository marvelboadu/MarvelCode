<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../hr_login.php");
    exit();
}

include '../../includes/db_connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Vacations - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-12">
            <h4>Vacations</h4>
            <a href="add_vacation.php" class="btn btn-success mb-3">Add New Vacation</a>
            <a href="../dashboard_hr.php" class="btn btn-secondary mb-3">Back to Dashboard</a>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Employee ID</th>
                        <th>From Date</th>
                        <th>To Date</th>
                        <th>Type</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT * FROM vacations";
                    $stmt = $conn->prepare($sql);
                    $stmt->execute();
                    $vacations = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    if (count($vacations) > 0) {
                        foreach ($vacations as $row) {
                            echo "<tr>
                                    <td>{$row['vacation_id']}</td>
                                    <td>{$row['vacation_employee_id']}</td>
                                    <td>{$row['vacation_from_date']}</td>
                                    <td>{$row['vacation_to_date']}</td>
                                    <td>{$row['vacation_type']}</td>
                                    <td>
                                        <a href='edit_vacation.php?id={$row['vacation_id']}' class='btn btn-primary'>Edit</a>
                                        <a href='delete_vacation.php?id={$row['vacation_id']}' class='btn btn-danger' onclick='return confirm(\"Are you sure you want to delete this vacation?\");'>Delete</a>
                                    </td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6' class='text-center'>No records found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
