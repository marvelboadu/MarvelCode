<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../hr_login.php");
    exit();
}

include '../../includes/db_connect.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: list_vacations.php");
    exit();
}

$vacation_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);

if ($vacation_id === false || $vacation_id === null) {
    header("Location: list_vacations.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $employee_id = $_POST['employee_id'];
    $from_date = $_POST['from_date'];
    $to_date = $_POST['to_date'];
    $vacation_type = $_POST['vacation_type'];

    $sql = "UPDATE vacations SET vacation_employee_id=:employee_id, vacation_from_date=:from_date, vacation_to_date=:to_date, vacation_type=:vacation_type WHERE vacation_id=:vacation_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':employee_id', $employee_id);
    $stmt->bindParam(':from_date', $from_date);
    $stmt->bindParam(':to_date', $to_date);
    $stmt->bindParam(':vacation_type', $vacation_type);
    $stmt->bindParam(':vacation_id', $vacation_id);

    if ($stmt->execute()) {
        header("Location: list_vacations.php");
    } else {
        echo "Error updating record: " . $stmt->errorInfo()[2];
    }
} else {
    $sql = "SELECT * FROM vacations WHERE vacation_id=:vacation_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':vacation_id', $vacation_id);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        header("Location: list_vacations.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Vacation - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-6 offset-md-3">
            <div class="card">
                <div class="card-header">
                    <h4>Edit Vacation</h4>
                </div>
                <div class="card-body">
                    <form action="edit_vacation.php?id=<?php echo $vacation_id; ?>" method="POST">
                        <div class="form-group">
                            <label for="employee_id">Employee ID</label>
                            <input type="text" class="form-control" id="employee_id" name="employee_id" value="<?php echo $row['vacation_employee_id']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="from_date">From Date</label>
                            <input type="date" class="form-control" id="from_date" name="from_date" value="<?php echo $row['vacation_from_date']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="to_date">To Date</label>
                            <input type="date" class="form-control" id="to_date" name="to_date" value="<?php echo $row['vacation_to_date']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="vacation_type">Vacation Type</label>
                            <input type="text" class="form-control" id="vacation_type" name="vacation_type" value="<?php echo $row['vacation_type']; ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Update Vacation</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
