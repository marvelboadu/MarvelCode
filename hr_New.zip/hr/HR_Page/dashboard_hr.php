<?php
// Include the database connection file
include '../includes/db_connect.php';

// Function to get count from database table
function getCount($conn, $table, $column = '*') {
    $sql = "SELECT COUNT($column) AS count FROM $table";
    $stmt = $conn->query($sql);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['count'];
}

// Initialize counts from database
$employee_count = getCount($conn, 'employee');
$department_count = getCount($conn, 'departments');
$leave_count = getCount($conn, 'leave_applications');
$training_count = getCount($conn, 'trainings');
$salary_count = getCount($conn, 'salaries');
$attendance_count = getCount($conn, 'attendance');
$evaluation_count = getCount($conn, 'evaluation');
$vacation_count = getCount($conn, 'vacations');

// Close the database connection
$conn = null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <title>HR Dashboard - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet"> -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            min-height: 100vh;
            background-color: #f8f9fa;
            font-family: 'Roboto', sans-serif;
        }
        .sidebar {
            width: 250px;
            background: #343a40;
            color: #fff;
            padding: 15px;
            transition: width 0.3s;
        }
        .sidebar a {
            color: #fff;
            text-decoration: none;
            display: block;
            padding: 10px;
            transition: background 0.3s, color 0.3s;
        }
        .sidebar a:hover {
            background: #495057;
            color: #ffc107;
        }
        .sidebar h3 {
            font-weight: bold;
        }
        .main-content {
            flex: 1;
            padding: 20px;
            background: #ffffff;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        .card {
            transition: transform 0.3s, box-shadow 0.3s;
            border-radius: 10px;
            border: none;
            height: 100%;
        }
        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }
        .card-title {
            font-size: 1.25rem;
            font-weight: 700;
            color: #007bff;
        }
        .card-text {
            font-size: 1rem;
            color: #6c757d;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            transition: background-color 0.3s, border-color 0.3s;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
    </style>
</head>
<body>
<div class="sidebar">
    <h3>HR Dashboard</h3>
    <a href="dashboard_hr.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="employees/list_employees.php"><i class="fas fa-users"></i> Employees</a>
    <a href="add_member.php"><i class="fas fa-user-plus"></i> Add New Member</a>
    <a href="departments/list_departments.php"><i class="fas fa-building"></i> Departments</a>
    <a href="leave_applications/list_leave_applications.php"><i class="fas fa-file-alt"></i> Leave Applications</a>
    <a href="trainings/list_trainings.php"><i class="fas fa-chalkboard-teacher"></i> Trainings</a>
    <a href="salaries/list_salaries.php"><i class="fas fa-dollar-sign"></i> Salaries</a>
    <a href="attendance/list_attendance.php"><i class="fas fa-calendar-check"></i> Attendance</a>
    <a href="evaluations/list_evaluations.php"><i class="fas fa-clipboard"></i> Evaluations</a>
    <a href="vacations/list_vacations.php"><i class="fas fa-plane"></i> Vacations</a>
   
    <a href="hr_logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>
<div class="main-content">
    <h1 class="mb-4">Welcome Back HR</h1>
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-12 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Employees</h5>
                            <p class="card-text">Total: <?php echo $employee_count; ?></p>
                            <a href="employees/list_employees.php" class="btn btn-primary">View Employees</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Departments</h5>
                            <p class="card-text">Total: <?php echo $department_count; ?></p>
                            <a href="departments/list_departments.php" class="btn btn-primary">View Departments</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-12 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Leave Applications</h5>
                            <p class="card-text">Total: <?php echo $leave_count; ?></p>
                            <a href="leave_applications/list_leave_applications.php" class="btn btn-primary">View Leave Applications</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Trainings</h5>
                            <p class="card-text">Total: <?php echo $training_count; ?></p>
                            <a href="trainings/list_trainings.php" class="btn btn-primary">View Trainings</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Salaries</h5>
                            <p class="card-text">Total: <?php echo $salary_count; ?></p>
                            <a href="salaries/list_salaries.php" class="btn btn-primary">View Salaries</a>
                        </div>
                    </div>
                </div>
            </div>
    
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-12 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Attendance</h5>
                            <p class="card-text">Total: <?php echo $attendance_count; ?></p>
                            <a href="attendance/list_attendance.php" class="btn btn-primary">View Attendance</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Evaluations</h5>
                            <p class="card-text">Total: <?php echo $evaluation_count; ?></p>
                            <a href="evaluations/list_evaluations.php" class="btn btn-primary">View Evaluations</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Vacations</h5>
                            <p class="card-text">Total: <?php echo isset($vacation_count) ? $vacation_count : 'N/A'; ?></p>
                            <a href="vacations/list_vacations.php" class="btn btn-primary">View Vacations</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>
</html>
