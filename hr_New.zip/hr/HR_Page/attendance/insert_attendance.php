<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}

include '../../includes/db_connect.php';

$employee_id = $_POST['employee_id'];
$date = $_POST['date'];
$status = $_POST['status'];

$sql = "INSERT INTO attendance (attendance_employee_id, attendance_date, status) VALUES ('$employee_id', '$date', '$status')";

if ($conn->query($sql) === TRUE) {
    header("Location: list_attendance.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
