<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}

include '../../includes/db_connect.php';

if (isset($_GET['id'])) {
    $attendance_id = $_GET['id'];
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $employee_id = $_POST['employee_id'];
        $date = $_POST['date'];
        $status = $_POST['status'];
        
        $sql = "UPDATE attendance SET attendance_employee_id = :employee_id, attendance_date = :date, status = :status WHERE attendance_id = :attendance_id";
        
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':employee_id', $employee_id);
        $stmt->bindParam(':date', $date);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':attendance_id', $attendance_id);
        
        if ($stmt->execute()) {
            header("Location: list_attendance.php");
        } else {
            echo "Error: " . $stmt->errorInfo()[2];
        }
    } else {
        $sql = "SELECT * FROM attendance WHERE attendance_id = :attendance_id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':attendance_id', $attendance_id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
    }
} else {
    header("Location: list_attendance.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Attendance - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-6 offset-md-3">
            <div class="card">
                <div class="card-header">
                    <h4>Edit Attendance</h4>
                </div>
                <div class="card-body">
                    <form action="edit_attendance.php?id=<?php echo $attendance_id; ?>" method="POST">
                        <div class="form-group">
                            <label for="employee_id">Employee ID</label>
                            <input type="number" class="form-control" id="employee_id" name="employee_id" value="<?php echo $row['attendance_employee_id']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="date">Date</label>
                            <input type="date" class="form-control" id="date" name="date" value="<?php echo $row['attendance_date']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select class="form-control" id="status" name="status" required>
                                <option value="Present" <?php echo ($row['status'] == 'Present') ? 'selected' : ''; ?>>Present</option>
                                <option value="Absent" <?php echo ($row['status'] == 'Absent') ? 'selected' : ''; ?>>Absent</option>
                                <option value="Leave" <?php echo ($row['status'] == 'Leave') ? 'selected' : ''; ?>>Leave</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Update Attendance</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
