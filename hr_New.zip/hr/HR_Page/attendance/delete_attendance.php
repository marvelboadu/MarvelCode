<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}

include '../../includes/db_connect.php';

if (isset($_GET['id'])) {
    $attendance_id = $_GET['id'];
    $sql = "DELETE FROM attendance WHERE attendance_id = :attendance_id";
    
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':attendance_id', $attendance_id);
    
    if ($stmt->execute()) {
        header("Location: list_attendance.php");
    } else {
        echo "Error: " . $stmt->errorInfo()[2];
    }
} else {
    header("Location: list_attendance.php");
}

$conn = null; // Close connection
?>
