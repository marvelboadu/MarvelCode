<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}
include '../../includes/db_connect.php';

// Sanitize and validate inputs (example: ensure date formats are correct, leave_type and leave_status are valid, etc.)
$employee_id = $_POST['employee_id'];
$leave_from_date = $_POST['leave_from_date'];
$leave_to_date = $_POST['leave_to_date'];
$leave_type = $_POST['leave_type'];
$leave_status = $_POST['leave_status'];

// Prepare the SQL statement
$sql = "INSERT INTO leave_applications (employee_id, leave_from_date, leave_to_date, leave_type, leave_status) 
        VALUES (?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

// Bind parameters
$stmt->bindParam(1, $employee_id);
$stmt->bindParam(2, $leave_from_date);
$stmt->bindParam(3, $leave_to_date);
$stmt->bindParam(4, $leave_type);
$stmt->bindParam(5, $leave_status);

// Execute the statement
if ($stmt->execute()) {
    header("Location: list_leave_applications.php");
    exit();
} else {
    // Print detailed error information
    $errorInfo = $stmt->errorInfo();
    echo "Error: " . $errorInfo[2]; // Index 2 contains the error message
}

// Close the connection (optional)
$conn = null;
?>
