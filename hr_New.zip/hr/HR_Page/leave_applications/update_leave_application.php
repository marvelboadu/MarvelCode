<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}
include '../../includes/db_connect.php';

// Sanitize input (ensure proper validation and sanitization for production use)
$leave_id = $_POST['leave_id'];
$employee_id = $_POST['employee_id'];
$leave_from_date = $_POST['leave_from_date'];
$leave_to_date = $_POST['leave_to_date'];
$leave_type = $_POST['leave_type'];
$leave_status = $_POST['leave_status'];

// Prepare the SQL statement
$sql = "UPDATE leave_applications SET 
        employee_id = ?, 
        leave_from_date = ?, 
        leave_to_date = ?, 
        leave_type = ?, 
        leave_status = ? 
        WHERE leave_id = ?";

$stmt = $conn->prepare($sql);

// Bind parameters
$stmt->bindParam(1, $employee_id);
$stmt->bindParam(2, $leave_from_date);
$stmt->bindParam(3, $leave_to_date);
$stmt->bindParam(4, $leave_type);
$stmt->bindParam(5, $leave_status);
$stmt->bindParam(6, $leave_id);

// Execute the statement
if ($stmt->execute()) {
    header("Location: list_leave_applications.php");
    exit();
} else {
    echo "Error: " . implode(" ", $conn->errorInfo());
}

// Close the connection
$conn = null;
?>
