<?php
session_start();

// Redirect to login page if user is not authenticated
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}

// Include database connection
include '../../includes/db_connect.php';

// Check if leave_id is provided in the URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: list_leave_applications.php");
    exit();
}

// Sanitize the input to ensure it's an integer
$leave_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);

if ($leave_id === false || $leave_id === null) {
    header("Location: list_leave_applications.php");
    exit();
}

// Prepare the DELETE statement
$sql = "DELETE FROM leave_applications WHERE leave_id = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    echo "Error preparing statement: " . $conn->errorInfo()[2];
    exit();
}

// Bind parameters and execute the statement
$stmt->bindParam(1, $leave_id, PDO::PARAM_INT); // Bind parameter as integer
$stmt->execute();

// Check for errors during execution
if ($stmt->errorInfo()[0] !== '00000') {
    echo "Error executing statement: " . $stmt->errorInfo()[2];
    exit();
}

// Check if deletion was successful
if ($stmt->rowCount() > 0) {
    // Redirect to list_leave_applications.php upon successful deletion
    header("Location: list_leave_applications.php");
    exit();
} else {
    // Redirect with error message if deletion fails
    echo "Error deleting leave application.";
}

// Close the statement and database connection
$stmt = null; // Close statement
$conn = null; // Close connection
?>
