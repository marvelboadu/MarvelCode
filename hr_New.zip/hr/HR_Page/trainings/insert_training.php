<?php
include '../../includes/db_connect.php';

$training_name = $_POST['training_name'];
$training_description = $_POST['training_description'];

$sql = "INSERT INTO training (training_name, training_description) VALUES ('$training_name', '$training_description')";

if ($conn->query($sql) === TRUE) {
    header("Location: list_trainings.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
