<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../hr_login.php");
    exit();
}

include '../../includes/db_connect.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: list_trainings.php");
    exit();
}

$training_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);

if ($training_id === false || $training_id === null) {
    header("Location: list_trainings.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $training_name = $_POST['training_name'];
    $training_description = $_POST['training_description'];

    $sql = "UPDATE trainings SET training_name=:training_name, training_description=:training_description WHERE training_id=:training_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':training_name', $training_name);
    $stmt->bindParam(':training_description', $training_description);
    $stmt->bindParam(':training_id', $training_id);

    if ($stmt->execute()) {
        header("Location: list_trainings.php");
    } else {
        echo "Error updating record: " . $stmt->errorInfo()[2];
    }
} else {
    $sql = "SELECT * FROM trainings WHERE training_id=:training_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':training_id', $training_id);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        header("Location: list_trainings.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Training - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-6 offset-md-3">
            <div class="card">
                <div class="card-header">
                    <h4>Edit Training</h4>
                </div>
                <div class="card-body">
                    <form action="edit_training.php?id=<?php echo $training_id; ?>" method="POST">
                        <div class="form-group">
                            <label for="training_name">Name</label>
                            <input type="text" class="form-control" id="training_name" name="training_name" value="<?php echo $row['training_name']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="training_description">Description</label>
                            <input type="text" class="form-control" id="training_description" name="training_description" value="<?php echo $row['training_description']; ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Update Training</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
