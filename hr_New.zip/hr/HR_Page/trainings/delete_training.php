<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../hr_login.php");
    exit();
}

include '../../includes/db_connect.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: list_trainings.php");
    exit();
}

$training_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);

if ($training_id === false || $training_id === null) {
    header("Location: list_trainings.php");
    exit();
}

$sqlDelete = "DELETE FROM trainings WHERE training_id = :training_id";
$stmtDelete = $conn->prepare($sqlDelete);
$stmtDelete->bindParam(':training_id', $training_id);

if ($stmtDelete->execute()) {
    header("Location: list_trainings.php");
    exit();
} else {
    echo "Error deleting training: " . $stmtDelete->errorInfo()[2];
}
?>
