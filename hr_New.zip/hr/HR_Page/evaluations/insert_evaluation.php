<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}

include '../../includes/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $employee_id = $conn->real_escape_string($_POST['employee_id']);
    $evaluation_comments = $conn->real_escape_string($_POST['evaluation_comments']);

    $sql = "INSERT INTO evaluation (employee_id, eval_valuenotes) VALUES ('$employee_id', '$evaluation_comments')";

    if ($conn->query($sql) === TRUE) {
        header("Location: list_evaluations.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
