<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}

include '../../includes/db_connect.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: list_employees.php");
    exit();
}

$employee_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);

if ($employee_id === false || $employee_id === null) {
    header("Location: list_employees.php");
    exit();
}

$sqlCheck = "SELECT COUNT(*) FROM leave_applications WHERE employee_id = :employee_id";
$stmtCheck = $conn->prepare($sqlCheck);
$stmtCheck->bindParam(':employee_id', $employee_id);
$stmtCheck->execute();
$count = $stmtCheck->fetchColumn();

if ($count > 0) {
    header("Location: list_employees.php?error=related_records_exist");
    exit();
} else {
    $sqlDelete = "DELETE FROM employee WHERE employee_id = :employee_id";
    $stmtDelete = $conn->prepare($sqlDelete);
    $stmtDelete->bindParam(':employee_id', $employee_id);

    if ($stmtDelete->execute()) {
        header("Location: list_employees.php");
        exit();
    } else {
        echo "Error deleting employee: " . $stmtDelete->errorInfo()[2];
    }
}
?>
