<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}

include '../../includes/db_connect.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: list_employees.php");
    exit();
}

$employee_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);

if ($employee_id === false || $employee_id === null) {
    header("Location: list_employees.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $employee_name = $_POST['employee_name'];
    $employee_email = $_POST['employee_email'];
    $employee_address = $_POST['employee_address'];
    $employee_mobile = $_POST['employee_mobile'];

    $sql = "UPDATE employee SET employee_name=:employee_name, employee_email=:employee_email, employee_address=:employee_address, employee_mobile=:employee_mobile WHERE employee_id=:employee_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':employee_name', $employee_name);
    $stmt->bindParam(':employee_email', $employee_email);
    $stmt->bindParam(':employee_address', $employee_address);
    $stmt->bindParam(':employee_mobile', $employee_mobile);
    $stmt->bindParam(':employee_id', $employee_id);

    if ($stmt->execute()) {
        header("Location: list_employees.php");
    } else {
        echo "Error updating record: " . $stmt->errorInfo()[2];
    }
} else {
    $sql = "SELECT * FROM employee WHERE employee_id=:employee_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':employee_id', $employee_id);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        header("Location: list_employees.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Employee - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-6 offset-md-3">
            <div class="card">
                <div class="card-header">
                    <h4>Edit Employee</h4>
                </div>
                <div class="card-body">
                    <form action="edit_employee.php?id=<?php echo $employee_id; ?>" method="POST">
                        <div class="form-group">
                            <label for="employee_name">Name</label>
                            <input type="text" class="form-control" id="employee_name" name="employee_name" value="<?php echo $row['employee_name']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="employee_email">Email</label>
                            <input type="email" class="form-control" id="employee_email" name="employee_email" value="<?php echo $row['employee_email']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="employee_address">Address</label>
                            <input type="text" class="form-control" id="employee_address" name="employee_address" value="<?php echo $row['employee_address']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="employee_mobile">Mobile</label>
                            <input type="text" class="form-control" id="employee_mobile" name="employee_mobile" value="<?php echo $row['employee_mobile']; ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Update Employee</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
