<?php
include '../../includes/db_connect.php';

$employee_name = $_POST['employee_name'];
$employee_email = $_POST['employee_email'];
$employee_password = $_POST['employee_password'];
$employee_address = $_POST['employee_address'];
$employee_mobile = $_POST['employee_mobile'];

$sql = "INSERT INTO employee (employee_name, employee_email, employee_password, employee_address, employee_mobile) VALUES ('$employee_name','$employee_email', '$employee_password', '$employee_address', '$employee_mobile')";

if ($conn->query($sql) === TRUE) {
    header("Location: list_employees.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
