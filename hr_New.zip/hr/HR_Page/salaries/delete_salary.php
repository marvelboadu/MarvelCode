<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../hr_login.php");
    exit();
}

include '../../includes/db_connect.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: list_salaries.php");
    exit();
}

$salary_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);

if ($salary_id === false || $salary_id === null) {
    header("Location: list_salaries.php");
    exit();
}

$sqlDelete = "DELETE FROM salaries WHERE salary_id = :salary_id";
$stmtDelete = $conn->prepare($sqlDelete);
$stmtDelete->bindParam(':salary_id', $salary_id);

if ($stmtDelete->execute()) {
    header("Location: list_salaries.php");
    exit();
} else {
    echo "Error deleting salary: " . $stmtDelete->errorInfo()[2];
}
?>
