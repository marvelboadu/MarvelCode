<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../hr_login.php");
    exit();
}

include '../../includes/db_connect.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: list_departments.php");
    exit();
}

$department_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);

if ($department_id === false || $department_id === null) {
    header("Location: list_departments.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $department_name = $_POST['department_name'];
    $department_description = $_POST['department_description'];

    $sql = "UPDATE departments SET department_name=:department_name, department_description=:department_description WHERE department_id=:department_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':department_name', $department_name);
    $stmt->bindParam(':department_description', $department_description);
    $stmt->bindParam(':department_id', $department_id);

    if ($stmt->execute()) {
        header("Location: list_departments.php");
    } else {
        echo "Error updating record: " . $stmt->errorInfo()[2];
    }
} else {
    $sql = "SELECT * FROM departments WHERE department_id=:department_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':department_id', $department_id);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        header("Location: list_departments.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Department - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-6 offset-md-3">
            <div class="card">
                <div class="card-header">
                    <h4>Edit Department</h4>
                </div>
                <div class="card-body">
                    <form action="edit_department.php?id=<?php echo $department_id; ?>" method="POST">
                        <div class="form-group">
                            <label for="department_name">Name</label>
                            <input type="text" class="form-control" id="department_name" name="department_name" value="<?php echo $row['department_name']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="department_description">Description</label>
                            <input type="text" class="form-control" id="department_description" name="department_description" value="<?php echo $row['department_description']; ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Update Department</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
