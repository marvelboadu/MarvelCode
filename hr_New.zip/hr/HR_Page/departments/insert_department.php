<?php
include '../../includes/db_connect.php';

$department_name = $_POST['department_name'];
$department_description = $_POST['department_description'];

$sql = "INSERT INTO departments (department_name, department_description) VALUES ('$department_name', '$department_description')";

if ($conn->query($sql) === TRUE) {
    header("Location: list_departments.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
