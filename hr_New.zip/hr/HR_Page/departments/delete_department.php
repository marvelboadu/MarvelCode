<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../hr_login.php");
    exit();
}

include '../../includes/db_connect.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: list_departments.php");
    exit();
}

$department_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);

if ($department_id === false || $department_id === null) {
    header("Location: list_departments.php");
    exit();
}

$sqlDelete = "DELETE FROM departments WHERE department_id = :department_id";
$stmtDelete = $conn->prepare($sqlDelete);
$stmtDelete->bindParam(':department_id', $department_id);

if ($stmtDelete->execute()) {
    header("Location: list_departments.php");
    exit();
} else {
    echo "Error deleting department: " . $stmtDelete->errorInfo()[2];
}
?>
