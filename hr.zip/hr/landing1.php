<html>
  <head>
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="" />
    <link
      rel="stylesheet"
      as="style"
      onload="this.rel='stylesheet'"
      href="https://fonts.googleapis.com/css2?display=swap&amp;family=Noto+Sans%3Awght%40400%3B500%3B700%3B900&amp;family=Work+Sans%3Awght%40400%3B500%3B700%3B900"
    />

    <title>Galileo Design</title>
    <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64," />

    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  </head>
  <body>
    <div class="relative flex size-full min-h-screen flex-col bg-white group/design-root overflow-x-hidden" style='font-family: "Work Sans", "Noto Sans", sans-serif;'>
      <div class="layout-container flex h-full grow flex-col">
        <header class="flex items-center justify-between whitespace-nowrap border-b border-solid border-b-[#f0f2f4] px-10 py-3">
          <div class="flex items-center gap-4 text-[#111418]">
            <div class="size-4">
              <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M44 11.2727C44 14.0109 39.8386 16.3957 33.69 17.6364C39.8386 18.877 44 21.2618 44 24C44 26.7382 39.8386 29.123 33.69 30.3636C39.8386 31.6043 44 33.9891 44 36.7273C44 40.7439 35.0457 44 24 44C12.9543 44 4 40.7439 4 36.7273C4 33.9891 8.16144 31.6043 14.31 30.3636C8.16144 29.123 4 26.7382 4 24C4 21.2618 8.16144 18.877 14.31 17.6364C8.16144 16.3957 4 14.0109 4 11.2727C4 7.25611 12.9543 4 24 4C35.0457 4 44 7.25611 44 11.2727Z"
                  fill="currentColor"
                ></path>
              </svg>
            </div>
            <h2 class="text-[#111418] text-lg font-bold leading-tight tracking-[-0.015em]">People First HR</h2>
          </div>
          <div class="flex flex-1 justify-end gap-8">
            <div class="flex items-center gap-9">
              <a class="text-[#111418] text-sm font-medium leading-normal" href="#">Solutions</a>
              <a class="text-[#111418] text-sm font-medium leading-normal" href="#">Resources</a>
              <a class="text-[#111418] text-sm font-medium leading-normal" href="#">Pricing</a>
              <a class="text-[#111418] text-sm font-medium leading-normal" href="#">Log In</a>
            </div>
            <button
              class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-10 px-4 bg-[#1980e6] text-white text-sm font-bold leading-normal tracking-[0.015em]"
            >
              <span class="truncate">Get started</span>
            </button>
          </div>
        </header>
        <div class="px-40 flex flex-1 justify-center py-5">
          <div class="layout-content-container flex flex-col max-w-[960px] flex-1">
            <div class="@container">
              <div class="@[480px]:p-4">
                <div
                  class="flex min-h-[480px] flex-col gap-6 bg-cover bg-center bg-no-repeat @[480px]:gap-8 @[480px]:rounded-xl items-start justify-end px-4 pb-10 @[480px]:px-10"
                  style='background-image: linear-gradient(rgba(0, 0, 0, 0.1) 0%, rgba(0, 0, 0, 0.4) 100%), url("https://cdn.usegalileo.ai/stability/1f30287d-1de9-4f89-b88f-a0f9e985f040.png");'
                >
                  <div class="flex flex-col gap-2 text-left">
                    <h1
                      class="text-white text-4xl font-black leading-tight tracking-[-0.033em] @[480px]:text-5xl @[480px]:font-black @[480px]:leading-tight @[480px]:tracking-[-0.033em]"
                    >
                      We help companies build a better workplace
                    </h1>
                    <h2 class="text-white text-sm font-normal leading-normal @[480px]:text-base @[480px]:font-normal @[480px]:leading-normal">
                      Empower your team with HR tools that help them grow, develop, and thrive. Say goodbye to spreadsheets and hello to People First HR.
                    </h2>
                  </div>
                  <button
                    class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-10 px-4 @[480px]:h-12 @[480px]:px-5 bg-[#1980e6] text-white text-sm font-bold leading-normal tracking-[0.015em] @[480px]:text-base @[480px]:font-bold @[480px]:leading-normal @[480px]:tracking-[0.015em]"
                  >
                    <span class="truncate">Get started</span>
                  </button>
                </div>
              </div>
            </div>
            <div class="flex flex-col gap-10 px-4 py-10 @container">
              <div class="flex flex-col gap-4">
                <h1
                  class="text-[#111418] tracking-light text-[32px] font-bold leading-tight @[480px]:text-4xl @[480px]:font-black @[480px]:leading-tight @[480px]:tracking-[-0.033em] max-w-[720px]"
                >
                  All the tools you need to manage your team
                </h1>
                <p class="text-[#111418] text-base font-normal leading-normal max-w-[720px]">
                  Our HR platform has everything you need to support your team, all in one place. From onboarding new hires to tracking time off, we've got you covered.
                </p>
              </div>
              <div class="grid grid-cols-[repeat(auto-fit,minmax(158px,1fr))] gap-3">
                <div class="flex flex-col gap-3 pb-3">
                  <div
                    class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl"
                    style='background-image: url("https://cdn.usegalileo.ai/stability/4181227a-ef6b-4a14-881e-b108f9623669.png");'
                  ></div>
                  <p class="text-[#111418] text-base font-medium leading-normal">Performance Management</p>
                </div>
                <div class="flex flex-col gap-3 pb-3">
                  <div
                    class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl"
                    style='background-image: url("https://cdn.usegalileo.ai/stability/36f779f6-87e5-4da2-8c08-c98c097a86e0.png");'
                  ></div>
                  <p class="text-[#111418] text-base font-medium leading-normal">Employee Self-Service</p>
                </div>
                <div class="flex flex-col gap-3 pb-3">
                  <div
                    class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl"
                    style='background-image: url("https://cdn.usegalileo.ai/stability/6a50c7b5-0d81-486c-95df-b646ca9f565b.png");'
                  ></div>
                  <p class="text-[#111418] text-base font-medium leading-normal">Analytics &amp; Reporting</p>
                </div>
                <div class="flex flex-col gap-3 pb-3">
                  <div
                    class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl"
                    style='background-image: url("https://cdn.usegalileo.ai/stability/b5af8773-954b-484b-87b4-0621ff435cee.png");'
                  ></div>
                  <p class="text-[#111418] text-base font-medium leading-normal">Onboarding &amp; Offboarding</p>
                </div>
                <div class="flex flex-col gap-3 pb-3">
                  <div
                    class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl"
                    style='background-image: url("https://cdn.usegalileo.ai/stability/89c5e82f-86e7-465e-874a-14a89b0e0ddd.png");'
                  ></div>
                  <p class="text-[#111418] text-base font-medium leading-normal">Time &amp; Leave Management</p>
                </div>
                <div class="flex flex-col gap-3 pb-3">
                  <div
                    class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl"
                    style='background-image: url("https://cdn.usegalileo.ai/stability/579c9e87-c75f-4981-a088-9cd46004c165.png");'
                  ></div>
                  <p class="text-[#111418] text-base font-medium leading-normal">Goal Setting &amp; Tracking</p>
                </div>
              </div>
            </div>
            <h2 class="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Trusted by 500+ companies</h2>
            <div class="grid grid-cols-[repeat(auto-fit,minmax(158px,1fr))] gap-3 p-4">
              <div class="flex flex-col gap-3">
                <div
                  class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl"
                  style='background-image: url("https://cdn.usegalileo.ai/sdxl10/bca6c6d1-edf6-4d64-8e2d-6b1d48438e35.png");'
                ></div>
              </div>
              <div class="flex flex-col gap-3">
                <div
                  class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl"
                  style='background-image: url("https://cdn.usegalileo.ai/sdxl10/a6d623ed-4d03-48b2-bd2c-fe90fa4ab26e.png");'
                ></div>
              </div>
              <div class="flex flex-col gap-3">
                <div
                  class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl"
                  style='background-image: url("https://cdn.usegalileo.ai/sdxl10/a86cfefa-d923-4e49-9718-ce4083dd7f4c.png");'
                ></div>
              </div>
              <div class="flex flex-col gap-3">
                <div
                  class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl"
                  style='background-image: url("https://cdn.usegalileo.ai/sdxl10/6a55b4de-4403-41de-8585-d501ccd2a40d.png");'
                ></div>
              </div>
              <div class="flex flex-col gap-3">
                <div
                  class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl"
                  style='background-image: url("https://cdn.usegalileo.ai/sdxl10/6d4d8049-a75e-48d1-a21c-e0ba0d79eafb.png");'
                ></div>
              </div>
              <div class="flex flex-col gap-3">
                <div
                  class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl"
                  style='background-image: url("https://cdn.usegalileo.ai/sdxl10/d95a4193-d57f-4b3a-95f4-09d67d29b64a.png");'
                ></div>
              </div>
            </div>
            <div class="@container">
              <div class="flex flex-col justify-end gap-6 px-4 py-10 @[480px]:gap-8 @[480px]:px-10 @[480px]:py-20">
                <div class="flex flex-col gap-2 text-center">
                  <h1
                    class="text-[#111418] tracking-light text-[32px] font-bold leading-tight @[480px]:text-4xl @[480px]:font-black @[480px]:leading-tight @[480px]:tracking-[-0.033em] max-w-[720px]"
                  >
                    Ready to give us a try?
                  </h1>
                </div>
                <div class="flex flex-1 justify-center">
                  <div class="flex justify-center">
                    <button
                      class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-10 px-4 @[480px]:h-12 @[480px]:px-5 bg-[#1980e6] text-white text-sm font-bold leading-normal tracking-[0.015em] @[480px]:text-base @[480px]:font-bold @[480px]:leading-normal @[480px]:tracking-[0.015em] grow"
                    >
                      <span class="truncate">Start your free trial</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
