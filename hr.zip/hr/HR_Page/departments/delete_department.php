<?php
include '../../includes/db_connect.php';

if (isset($_GET['id'])) {
    $department_id = $_GET['id'];

    try {
        $stmt = $conn->prepare("DELETE FROM departments WHERE department_id = :department_id");
        $stmt->bindParam(':department_id', $department_id);
        $stmt->execute();

        header("Location: list_departments.php");
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

    $conn = null; // Close the connection
} else {
    echo "Invalid request";
    exit();
}
?>
