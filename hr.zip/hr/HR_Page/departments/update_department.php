<?php
include '../../includes/db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Prepare and bind
        $stmt = $conn->prepare("UPDATE departments SET department_name = :department_name, department_description = :department_description WHERE department_id = :department_id");
        $stmt->bindParam(':department_name', $department_name);
        $stmt->bindParam(':department_description', $department_description);
        $stmt->bindParam(':department_id', $department_id);

        // Set parameters and execute
        $department_id = $_POST['department_id'];
        $department_name = $_POST['department_name'];
        $department_description = $_POST['department_description'];

        $stmt->execute();

        header("Location: list_departments.php");
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

    $conn = null; // Close the connection
}
?>
