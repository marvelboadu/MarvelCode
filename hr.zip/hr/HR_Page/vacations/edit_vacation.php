<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}

include '../../includes/db_connect.php';

$vacation_id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $vacation_employee_id = $_POST['vacation_employee_id'];
    $vacation_from_date = $_POST['vacation_from_date'];
    $vacation_to_date = $_POST['vacation_to_date'];
    $vacation_type = $_POST['vacation_type'];

    $sql = "UPDATE vacations SET vacation_employee_id = ?, vacation_from_date = ?, vacation_to_date = ?, vacation_type = ? WHERE vacation_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt->execute([$vacation_employee_id, $vacation_from_date, $vacation_to_date, $vacation_type, $vacation_id])) {
        header("Location: list_vacations.php");
        exit();
    } else {
        echo "Error: " . $stmt->errorInfo()[2];
    }
} else {
    $sql = "SELECT * FROM vacations WHERE vacation_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$vacation_id]);
    $vacation = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$vacation) {
        echo "Vacation not found!";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Vacation - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-12">
            <h4>Edit Vacation</h4>
            <form action="edit_vacation.php?id=<?php echo $vacation_id; ?>" method="POST">
                <div class="form-group">
                    <label for="vacation_employee_id">Employee ID</label>
                    <input type="text" name="vacation_employee_id" class="form-control" value="<?php echo $vacation['vacation_employee_id']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="vacation_from_date">From Date</label>
                    <input type="date" name="vacation_from_date" class="form-control" value="<?php echo $vacation['vacation_from_date']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="vacation_to_date">To Date</label>
                    <input type="date" name="vacation_to_date" class="form-control" value="<?php echo $vacation['vacation_to_date']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="vacation_type">Type</label>
                    <input type="text" name="vacation_type" class="form-control" value="<?php echo $vacation['vacation_type']; ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Update Vacation</button>
                <a href="list_vacations.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
