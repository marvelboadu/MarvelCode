<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}

include '../../includes/db_connect.php';

$vacation_id = $_GET['id'];

$sql = "DELETE FROM vacations WHERE vacation_id = ?";
$stmt = $conn->prepare($sql);
if ($stmt->execute([$vacation_id])) {
    header("Location: list_vacations.php");
    exit();
} else {
    echo "Error deleting record: " . $stmt->errorInfo()[2];
}
?>
