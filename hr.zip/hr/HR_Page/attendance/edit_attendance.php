<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}
include '../../includes/db_connect.php';

if (isset($_GET['id'])) {
    $attendance_id = $_GET['id'];

    // Fetch attendance details
    $stmt = $conn->prepare("SELECT * FROM attendance WHERE attendance_id = :attendance_id");
    $stmt->bindParam(':attendance_id', $attendance_id);
    $stmt->execute();
    $attendance = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$attendance) {
        echo "Attendance record not found";
        exit();
    }
} else {
    echo "Invalid request";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Attendance - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-12">
            <h4>Edit Attendance</h4>
            <a href="list_attendance.php" class="btn btn-secondary mb-3">Back to Attendance List</a>
            <form action="update_attendance.php" method="post">
                <input type="hidden" name="attendance_id" value="<?php echo $attendance['attendance_id']; ?>">
                <div class="form-group">
                    <label for="attendance_employee_id">Employee ID</label>
                    <input type="text" class="form-control" id="attendance_employee_id" name="attendance_employee_id" value="<?php echo $attendance['attendance_employee_id']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="attendance_date">Date</label>
                    <input type="date" class="form-control" id="attendance_date" name="attendance_date" value="<?php echo $attendance['attendance_date']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="status">Status</label>
                    <select class="form-control" id="status" name="status" required>
                        <option value="Present" <?php if($attendance['status'] == 'Present') echo 'selected'; ?>>Present</option>
                        <option value="Absent" <?php if($attendance['status'] == 'Absent') echo 'selected'; ?>>Absent</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Update Attendance</button>
            </form>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
