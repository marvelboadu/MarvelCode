<?php
include '../../includes/db_connect.php';

if (isset($_GET['id'])) {
    $attendance_id = $_GET['id'];

    try {
        $stmt = $conn->prepare("DELETE FROM attendance WHERE attendance_id = :attendance_id");
        $stmt->bindParam(':attendance_id', $attendance_id);
        $stmt->execute();

        header("Location: list_attendance.php");
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

    $conn = null; // Close the connection
} else {
    echo "Invalid request";
    exit();
}
?>
