<?php
session_start();
session_destroy();
header("Location: hr_login.php");
exit();
?>
