<?php
// Include the database connection
include '../includes/db_connect.php';

// Check if form is submitted
if (isset($_POST['submit'])) {
    // Get form data
    $employee_id = $_POST['employee_id'];
    $department_id = $_POST['department_id'];
    $training_id = $_POST['training_id'];
    $leave_id = $_POST['leave_id'];
    $amount = $_POST['amount'];
    $status = $_POST['status'];
    $eval_valuenotes = $_POST['eval_valuenotes'];
    $vacation_id = $_POST['vacation_id'];

    // Insert into respective tables (adjust as per your database schema)
    try {
        // Example insert statements
        $sql1 = "INSERT INTO salaries (employee_id, month, amount) VALUES (:employee_id, NOW(), :amount)";
        $stmt1 = $conn->prepare($sql1);
        $stmt1->bindParam(':employee_id', $employee_id);
        $stmt1->bindParam(':amount', $amount);
        $stmt1->execute();

        $sql2 = "INSERT INTO attendance (attendance_employee_id, attendance_date, status) VALUES (:employee_id, NOW(), :status)";
        $stmt2 = $conn->prepare($sql2);
        $stmt2->bindParam(':employee_id', $employee_id);
        $stmt2->bindParam(':status', $status);
        $stmt2->execute();

        $sql3 = "INSERT INTO evaluation (employee_id, eval_valuenotes) VALUES (:employee_id, :eval_valuenotes)";
        $stmt3 = $conn->prepare($sql3);
        $stmt3->bindParam(':employee_id', $employee_id);
        $stmt3->bindParam(':eval_valuenotes', $eval_valuenotes);
        $stmt3->execute();

        // Add more queries for other tables as needed

        // Redirect to dashboard on success
        header("Location: dashboard.php");
        exit();
    } catch (PDOException $e) {
        // Display error message on failure
        echo "Error: " . $e->getMessage();
    }
}
?>
