<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}

include '../../includes/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $training_employee_id = $_POST['training_employee_id'];
    $training_registration = $_POST['training_registration'];
    $training_name = $_POST['training_name'];
    $training_type = $_POST['training_type'];
    $training_year = $_POST['training_year'];
    $training_description = $_POST['training_description'];

    $sql = "INSERT INTO trainings (training_employee_id, training_registration, training_name, training_type, training_year, training_description) VALUES (:training_employee_id, :training_registration, :training_name, :training_type, :training_year, :training_description)";
    
    try {
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':training_employee_id', $training_employee_id);
        $stmt->bindParam(':training_registration', $training_registration);
        $stmt->bindParam(':training_name', $training_name);
        $stmt->bindParam(':training_type', $training_type);
        $stmt->bindParam(':training_year', $training_year);
        $stmt->bindParam(':training_description', $training_description);
        
        if ($stmt->execute()) {
            header("Location: list_trainings.php");
            exit();
        } else {
            echo "Error: Could not insert the training record.";
            $errorInfo = $stmt->errorInfo();
            echo "SQLSTATE: " . $errorInfo[0] . "<br>";
            echo "SQL Error Code: " . $errorInfo[1] . "<br>";
            echo "Message: " . $errorInfo[2] . "<br>";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Training - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-6 offset-md-3">
            <h4>Add New Training</h4>
            <form action="add_training.php" method="POST">
                <div class="form-group">
                    <label for="training_employee_id">Employee ID</label>
                    <input type="number" class="form-control" id="training_employee_id" name="training_employee_id" required>
                </div>
                <div class="form-group">
                    <label for="training_registration">Registration</label>
                    <input type="text" class="form-control" id="training_registration" name="training_registration" required>
                </div>
                <div class="form-group">
                    <label for="training_name">Training Name</label>
                    <input type="text" class="form-control" id="training_name" name="training_name" required>
                </div>
                <div class="form-group">
                    <label for="training_type">Training Type</label>
                    <input type="text" class="form-control" id="training_type" name="training_type" required>
                </div>
                <div class="form-group">
                    <label for="training_year">Training Year</label>
                    <input type="number" class="form-control" id="training_year" name="training_year" required>
                </div>
                <div class="form-group">
                    <label for="training_description">Training Description</label>
                    <textarea class="form-control" id="training_description" name="training_description" required></textarea>
                </div>
                <button type="submit" class="btn btn-success">Submit</button>
                <a href="list_trainings.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
