<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../hr_login.php");
    exit();
}

include '../../includes/db_connect.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: list_evaluations.php");
    exit();
}

$eval_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);

if ($eval_id === false || $eval_id === null) {
    header("Location: list_evaluations.php");
    exit();
}

$sqlDelete = "DELETE FROM evaluation WHERE eval_id = :eval_id";
$stmtDelete = $conn->prepare($sqlDelete);
$stmtDelete->bindParam(':eval_id', $eval_id);

if ($stmtDelete->execute()) {
    header("Location: list_evaluations.php");
    exit();
} else {
    echo "Error deleting evaluation: " . $stmtDelete->errorInfo()[2];
}
?>
