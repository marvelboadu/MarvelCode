<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}
include '../../includes/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $employee_id = $_POST['employee_id'];
    $leave_from_date = $_POST['leave_from_date'];
    $leave_to_date = $_POST['leave_to_date'];
    $leave_type = $_POST['leave_type'];
    $leave_status = $_POST['leave_status'];

    $sql = "INSERT INTO leave_applications (employee_id, leave_from_date, leave_to_date, leave_type, leave_status) VALUES (:employee_id, :leave_from_date, :leave_to_date, :leave_type, :leave_status)";
    
    try {
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':employee_id', $employee_id);
        $stmt->bindParam(':leave_from_date', $leave_from_date);
        $stmt->bindParam(':leave_to_date', $leave_to_date);
        $stmt->bindParam(':leave_type', $leave_type);
        $stmt->bindParam(':leave_status', $leave_status);
        
        if ($stmt->execute()) {
            header("Location: list_leave_applications.php");
            exit();
        } else {
            echo "Error: Could not insert the leave application.";
            $errorInfo = $stmt->errorInfo();
            echo "SQLSTATE: " . $errorInfo[0] . "<br>";
            echo "SQL Error Code: " . $errorInfo[1] . "<br>";
            echo "Message: " . $errorInfo[2] . "<br>";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
