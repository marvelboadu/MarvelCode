<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}
include '../../includes/db_connect.php';

if (!isset($_GET['id'])) {
    header("Location: list_leave_application.php");
    exit();
}

$leave_id = $_GET['id'];

$sql = "DELETE FROM leave_applications WHERE leave_id = :leave_id";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':leave_id', $leave_id);

if ($stmt->execute()) {
    header("Location: list_leave_applications.php");
    exit();
} else {
    echo "Error deleting record.";
}
?>
