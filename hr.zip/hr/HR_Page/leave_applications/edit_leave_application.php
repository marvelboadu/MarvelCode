<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}
include '../../includes/db_connect.php';

if (!isset($_GET['id'])) {
    header("Location: list_leave_application.php");
    exit();
}

$leave_id = $_GET['id'];

$sql = "SELECT * FROM leave_applications WHERE leave_id = :leave_id";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':leave_id', $leave_id);
$stmt->execute();
$leave = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$leave) {
    header("Location: list_leave_application.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Leave Application - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-6 offset-md-3">
            <h4>Edit Leave Application</h4>
            <form action="update_leave_application.php" method="POST">
                <input type="hidden" name="leave_id" value="<?php echo $leave['leave_id']; ?>">
                <div class="form-group">
                    <label for="employee_id">Employee ID</label>
                    <input type="text" class="form-control" id="employee_id" name="employee_id" value="<?php echo $leave['employee_id']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="leave_from_date">From Date</label>
                    <input type="date" class="form-control" id="leave_from_date" name="leave_from_date" value="<?php echo $leave['leave_from_date']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="leave_to_date">To Date</label>
                    <input type="date" class="form-control" id="leave_to_date" name="leave_to_date" value="<?php echo $leave['leave_to_date']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="leave_type">Type</label>
                    <input type="text" class="form-control" id="leave_type" name="leave_type" value="<?php echo $leave['leave_type']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="leave_status">Status</label>
                    <input type="text" class="form-control" id="leave_status" name="leave_status" value="<?php echo $leave['leave_status']; ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
                <a href="list_leave_applications.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
