<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}
include '../../includes/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $leave_id = $_POST['leave_id'];
    $employee_id = $_POST['employee_id'];
    $leave_from_date = $_POST['leave_from_date'];
    $leave_to_date = $_POST['leave_to_date'];
    $leave_type = $_POST['leave_type'];
    $leave_status = $_POST['leave_status'];

    $sql = "UPDATE leave_applications SET 
                employee_id = :employee_id, 
                leave_from_date = :leave_from_date, 
                leave_to_date = :leave_to_date, 
                leave_type = :leave_type, 
                leave_status = :leave_status 
            WHERE leave_id = :leave_id";

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':employee_id', $employee_id);
    $stmt->bindParam(':leave_from_date', $leave_from_date);
    $stmt->bindParam(':leave_to_date', $leave_to_date);
    $stmt->bindParam(':leave_type', $leave_type);
    $stmt->bindParam(':leave_status', $leave_status);
    $stmt->bindParam(':leave_id', $leave_id);

    if ($stmt->execute()) {
        header("Location: list_leave_applications.php");
        exit();
    } else {
        echo "Error updating record.";
    }
}
?>
