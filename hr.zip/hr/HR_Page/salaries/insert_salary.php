<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}

include '../../includes/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $employee_id = $conn->real_escape_string($_POST['employee_id']);
    $month = $conn->real_escape_string($_POST['month']);
    $amount = $conn->real_escape_string($_POST['amount']);

    $sql = "INSERT INTO salaries (employee_id, month, amount) VALUES ('$employee_id', '$month', '$amount')";

    if ($conn->query($sql) === TRUE) {
        header("Location: list_salaries.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
