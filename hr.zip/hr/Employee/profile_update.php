<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Include database connection
include '../includes/db_connect.php';

// Check if employee_id is set
if (!isset($_SESSION['employee_id'])) {
    echo "Employee ID is not set in the session.";
    exit();
}

$employee_id = $_SESSION['employee_id'];

// Initialize variables
$profile_image = '';
$name = '';
$email = '';
$address = '';
$mobile = '';
$update_success = false;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $mobile = $_POST['mobile'];

    // Handle file upload
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/';
        $upload_file = $upload_dir . basename($_FILES['profile_image']['name']);

        // Check file size (example: 2MB max)
        if ($_FILES['profile_image']['size'] > 2 * 1024 * 1024) {
            echo "Sorry, your file is too large.";
        } elseif (move_uploaded_file($_FILES['profile_image']['tmp_name'], $upload_file)) {
            $profile_image = basename($_FILES['profile_image']['name']);
        } else {
            echo "Sorry, your file was not uploaded.";
        }
    }

    // Update the database
    try {
        $sql = "UPDATE employee SET employee_name = :name, employee_email = :email, employee_address = :address, employee_mobile = :mobile, employee_image = :profile_image WHERE employee_id = :employee_id";
        $stmt = $db_conn->prepare($sql);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':mobile', $mobile);
        $stmt->bindParam(':profile_image', $profile_image);
        $stmt->bindParam(':employee_id', $employee_id);

        $stmt->execute();
        $update_success = true;
    } catch (PDOException $e) {
        echo "Update failed: " . $e->getMessage();
    }

    // If update is successful, redirect to profile page with success message
    if ($update_success) {
        $_SESSION['update_success'] = true;
        header('Location: profile.php');
        exit();
    }
}

// Fetch current employee data for pre-filling the form
try {
    $sql = "SELECT employee_name, employee_email, employee_address, employee_mobile, employee_image FROM employee WHERE employee_id = :employee_id";
    $stmt = $db_conn->prepare($sql);
    $stmt->bindParam(':employee_id', $employee_id);
    $stmt->execute();

    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($employee) {
        $name = $employee['employee_name'];
        $email = $employee['employee_email'];
        $address = $employee['employee_address'];
        $mobile = $employee['employee_mobile'];
        $profile_image = $employee['employee_image'];
    }
} catch (PDOException $e) {
    echo "Error fetching employee data: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile</title>
    <link rel="stylesheet" href="path/to/bootstrap.min.css">
    <style>
        /* Custom styling */
    </style>
</head>
<body>
    <div class="container">
        <h2>Update Profile</h2>
        <?php if ($update_success): ?>
            <div class="alert alert-success">Profile updated successfully.</div>
        <?php endif; ?>
        <form action="profile_update.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" class="form-control" value="<?php echo htmlspecialchars($name); ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>" required>
            </div>
            <div class="form-group">
                <label for="address">Address:</label>
                <input type="text" id="address" name="address" class="form-control" value="<?php echo htmlspecialchars($address); ?>" required>
            </div>
            <div class="form-group">
                <label for="mobile">Mobile:</label>
                <input type="text" id="mobile" name="mobile" class="form-control" value="<?php echo htmlspecialchars($mobile); ?>" required>
            </div>
            <div class="form-group">
                <label for="profile_image">Profile Image:</label>
                <input type="file" id="profile_image" name="profile_image" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
        <?php if ($profile_image): ?>
            <div class="mt-3">
                <img src="uploads/<?php echo htmlspecialchars($profile_image); ?>" alt="Profile Image" class="img-thumbnail" style="max-width: 200px;">
            </div>
        <?php endif; ?>
    </div>
    <script src="path/to/bootstrap.bundle.min.js"></script>
</body>
</html>
