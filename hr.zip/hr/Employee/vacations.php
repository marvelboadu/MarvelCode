<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: employee_login.php');
    exit();
}

// Include database connection file
require_once '../includes/db_connect.php';

// Fetch user ID from session
$user_id = $_SESSION['user_id'];

// Process vacation application form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input fields
    $vacation_from_date = $_POST['vacation_from_date'];
    $vacation_to_date = $_POST['vacation_to_date'];
    $vacation_type = $_POST['vacation_type'];

    // Prepare SQL statement to insert vacation application
    $query = "INSERT INTO vacations (vacation_employee_id, vacation_from_date, vacation_to_date, vacation_type) 
              VALUES (:employee_id, :from_date, :to_date, :vacation_type)";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':employee_id', $user_id, PDO::PARAM_INT);
    $stmt->bindParam(':from_date', $vacation_from_date, PDO::PARAM_STR);
    $stmt->bindParam(':to_date', $vacation_to_date, PDO::PARAM_STR);
    $stmt->bindParam(':vacation_type', $vacation_type, PDO::PARAM_STR);

    // Execute SQL statement
    if ($stmt->execute()) {
        echo '<div class="alert alert-success" role="alert">Vacation application submitted successfully!</div>';
    } else {
        echo '<div class="alert alert-danger" role="alert">Error submitting vacation application.</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vacations - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        /* Add custom styles here */
    </style>
</head>
<body>
    <div class="container">
        <h1>Vacations</h1>
        <div class="row">
            <div class="col-md-6">
                <form method="post">
                    <div class="form-group">
                        <label for="vacation_from_date">From Date:</label>
                        <input type="date" class="form-control" id="vacation_from_date" name="vacation_from_date" required>
                    </div>
                    <div class="form-group">
                        <label for="vacation_to_date">To Date:</label>
                        <input type="date" class="form-control" id="vacation_to_date" name="vacation_to_date" required>
                    </div>
                    <div class="form-group">
                        <label for="vacation_type">Vacation Type:</label>
                        <input type="text" class="form-control" id="vacation_type" name="vacation_type" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Apply Vacation</button>
                </form>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-md-6">
                <a href="profile.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
