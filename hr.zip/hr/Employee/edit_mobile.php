<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: employee_login.php');
    exit();
}

// Include database connection file (assuming it's db_connect.php)
require_once '../includes/db_connect.php';

// Fetch user data from session
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];
$user_email = $_SESSION['user_email'];
$employee_mobile = isset($_SESSION['employee_mobile']) ? $_SESSION['employee_mobile'] : '';

// Initialize variables for form validation
$new_mobile = $employee_mobile;
$update_success = false;
$error_message = '';

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate inputs
    $new_mobile = $_POST['mobile'];
    
    // Update mobile number in database using PDO prepared statement
    $query = "UPDATE employee SET employee_mobile = :new_mobile WHERE employee_id = :user_id";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':new_mobile', $new_mobile, PDO::PARAM_STR);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);

    if ($stmt->execute()) {
        // Update session variable
        $_SESSION['employee_mobile'] = $new_mobile;
        $update_success = true;

        // Redirect to profile.php after successful update
        header("Location: profile.php");
        exit();
    } else {
        $error_message = "Failed to update mobile number. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Mobile Number - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
        }
        .form-group {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Mobile Number</h2>
        <?php if ($update_success): ?>
            <div class="alert alert-success" role="alert">
                Mobile number updated successfully.
            </div>
        <?php elseif ($error_message !== ''): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
        <form method="POST">
            <div class="form-group">
                <label for="mobile">Mobile Number</label>
                <input type="text" class="form-control" id="mobile" name="mobile" value="<?php echo htmlspecialchars($new_mobile); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Update Mobile Number</button>
            <a href="profile.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
