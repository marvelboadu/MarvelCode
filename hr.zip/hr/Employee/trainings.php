<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: employee_login.php');
    exit();
}

// Include database connection file
require_once '../includes/db_connect.php';

// Fetch user ID from session
$user_id = $_SESSION['user_id'];

// Process training registration form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input fields
    $training_registration = $_POST['training_registration'];
    $training_name = $_POST['training_name'];
    $training_type = $_POST['training_type'];
    $training_year = $_POST['training_year'];
    $training_description = $_POST['training_description'];

    // Prepare SQL statement to insert training registration
    $query = "INSERT INTO trainings (training_employee_id, training_registration, training_name, training_type, training_year, training_description) 
              VALUES (:employee_id, :registration, :name, :type, :year, :description)";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':employee_id', $user_id, PDO::PARAM_INT);
    $stmt->bindParam(':registration', $training_registration, PDO::PARAM_STR);
    $stmt->bindParam(':name', $training_name, PDO::PARAM_STR);
    $stmt->bindParam(':type', $training_type, PDO::PARAM_STR);
    $stmt->bindParam(':year', $training_year, PDO::PARAM_INT);
    $stmt->bindParam(':description', $training_description, PDO::PARAM_STR);

    // Execute SQL statement
    if ($stmt->execute()) {
        echo '<div class="alert alert-success" role="alert">Training registration submitted successfully!</div>';
    } else {
        echo '<div class="alert alert-danger" role="alert">Error submitting training registration.</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trainings - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        /* Add custom styles here */
    </style>
</head>
<body>
    <div class="container">
        <h1>Trainings</h1>
        <a href="profile.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        <div class="row">
            <div class="col-md-6">
                <form method="post">
                    <div class="form-group">
                        <label for="training_registration">Registration ID:</label>
                        <input type="text" class="form-control" id="training_registration" name="training_registration" required>
                    </div>
                    <div class="form-group">
                        <label for="training_name">Training Name:</label>
                        <input type="text" class="form-control" id="training_name" name="training_name" required>
                    </div>
                    <div class="form-group">
                        <label for="training_type">Training Type:</label>
                        <input type="text" class="form-control" id="training_type" name="training_type" required>
                    </div>
                    <div class="form-group">
                        <label for="training_year">Training Year:</label>
                        <input type="number" class="form-control" id="training_year" name="training_year" required>
                    </div>
                    <div class="form-group">
                        <label for="training_description">Description:</label>
                        <textarea class="form-control" id="training_description" name="training_description" rows="3" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Register Training</button>
                </form>
            </div>
        </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
