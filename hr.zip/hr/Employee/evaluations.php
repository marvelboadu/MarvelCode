<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: employee_login.php');
    exit();
}

// Include database connection file
require_once '../includes/db_connect.php';

// Fetch user ID from session
$user_id = $_SESSION['user_id'];

// Fetch evaluation data
$query = "SELECT * FROM evaluation WHERE employee_id = :employee_id";
$stmt = $conn->prepare($query);
$stmt->bindParam(':employee_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$evaluation_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evaluations - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        /* Add custom styles here */
    </style>
</head>
<body>
    <div class="container">
        <h1>Evaluations</h1>
        <a href="profile.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        <div class="row">
            <div class="col-md-6">
                <ul class="list-group">
                    <?php foreach ($evaluation_data as $evaluation): ?>
                    <li class="list-group-item">
                        <h5>Employee ID: <?php echo $evaluation['employee_id']; ?></h5>
                        <p><?php echo $evaluation['eval_valuenotes']; ?></p>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
