<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: employee_login.php');
    exit();
}

// Fetch user data from session
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];
$user_email = $_SESSION['user_email'];
$employee_address = isset($_SESSION['employee_address']) ? $_SESSION['employee_address'] : '';
$employee_mobile = isset($_SESSION['employee_mobile']) ? $_SESSION['employee_mobile'] : '';

// Include database connection file
require_once '../includes/db_connect.php';

// Function to fetch attendance data
function fetchAttendanceData($db_conn, $employee_id) {
    $query = "SELECT MONTH(attendance_date) AS month, COUNT(*) AS days_present 
              FROM attendance 
              WHERE attendance_employee_id = :employee_id 
              GROUP BY MONTH(attendance_date)";
    $stmt = $db_conn->prepare($query);
    $stmt->bindParam(':employee_id', $employee_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to fetch salary data
function fetchSalaryData($db_conn, $employee_id) {
    $query = "SELECT DATE_FORMAT(month, '%M %Y') AS month, amount 
              FROM salaries 
              WHERE employee_id = :employee_id";
    $stmt = $db_conn->prepare($query);
    $stmt->bindParam(':employee_id', $employee_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to fetch training data
function fetchTrainingData($db_conn, $employee_id) {
    $query = "SELECT training_name, COUNT(*) AS training_count 
              FROM trainings 
              WHERE training_employee_id = :employee_id 
              GROUP BY training_name";
    $stmt = $db_conn->prepare($query);
    $stmt->bindParam(':employee_id', $employee_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to fetch vacation data
function fetchVacationData($db_conn, $employee_id) {
    $query = "SELECT vacation_type, DATEDIFF(vacation_to_date, vacation_from_date) AS vacation_days 
              FROM vacations 
              WHERE vacation_employee_id = :employee_id";
    $stmt = $db_conn->prepare($query);
    $stmt->bindParam(':employee_id', $employee_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
function fetchEmployeeImage($db_conn, $employee_id) {
    $query = "SELECT employee_image FROM employee WHERE employee_id = :employee_id";
    $stmt = $db_conn->prepare($query);
    $stmt->bindParam(':employee_id', $employee_id, PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $image_path = 'uploads/' . ($result ? $result['employee_image'] : 'no-image.jpg');
    return file_exists($image_path) ? $image_path : 'images/no-image.jpg';
}


// Establish database connection (replace with your database credentials)
$db_conn = new PDO('mysql:host=localhost;dbname=hr', 'root', '');

// Fetch data
$attendance_data = fetchAttendanceData($db_conn, $user_id);
$salary_data = fetchSalaryData($db_conn, $user_id);
$training_data = fetchTrainingData($db_conn, $user_id);
$vacation_data = fetchVacationData($db_conn, $user_id);
$employee_image = fetchEmployeeImage($db_conn, $user_id);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
        }
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #343a40;
            padding-top: 20px;
        }
        .sidebar a {
            padding: 15px;
            text-decoration: none;
            font-size: 18px;
            color: white;
            display: block;
        }
        .sidebar a:hover {
            background-color: #575d63;
        }
        .content {
            margin-left: 260px;
            padding: 20px;
        }
        .card {
            margin-bottom: 20px;
        }
        .small-chart {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
        <a href="attendance.php"><i class="fas fa-calendar-check"></i> Attendance</a>
        <a href="salaries.php"><i class="fas fa-dollar-sign"></i> Salaries</a>
        <a href="trainings.php"><i class="fas fa-chalkboard-teacher"></i> Trainings</a>
        <a href="vacations.php"><i class="fas fa-plane"></i> Vacations</a>
        <a href="evaluations.php"><i class="fas fa-star"></i> Evaluations</a>
        <a href="../Employee/employee_login.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h5>Personal Information</h5>
                        </div>
                        <div class="card-body">
                            <p>Hello <?php echo htmlspecialchars($user_name); ?>, you are welcome to our Human Resource 
                            Management platform. Here you can view all your information.</p>
                            <div class="text-center mt-4">
                            <img src="<?php echo htmlspecialchars($employee_image); ?>" alt="" class="img-fluid" style="width:140px; height:140px; object-fit:cover; border-radius:50%;">

                                <div>
                                    <button class="btn btn-primary m-1" data-toggle="modal" data-target="#editProfileModal">Edit</button>
                                </div>
                            </div>
                            <div>
                                <p><strong>Address:</strong> <?php echo htmlspecialchars($employee_address); ?></p>
                                <p><strong>Mobile:</strong> <?php echo htmlspecialchars($employee_mobile); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h5>Additional Information</h5>
                        </div>
                        <div class="card-body">
                            <?php
                            require_once '../includes/db_connect.php';

                           

                            // Fetch additional employee information
                            $query = "SELECT * FROM employee WHERE employee_id = :employee_id";
                            $stmt = $db_conn->prepare($query);
                            $stmt->bindParam(':employee_id', $employee_id, PDO::PARAM_INT);
                            $stmt->execute();
                            $employee_info = $stmt->fetch(PDO::FETCH_ASSOC);

                            if ($employee_info) {
                                echo "<p><strong>Department:</strong> " . htmlspecialchars($employee_info['department']) . "</p>";
                                echo "<p><strong>Position:</strong> " . htmlspecialchars($employee_info['position']) . "</p>";
                                echo "<p><strong>Date of Hire:</strong> " . htmlspecialchars($employee_info['date_of_hire']) . "</p>";
                                echo "<p><strong>Supervisor:</strong> " . htmlspecialchars($employee_info['supervisor']) . "</p>";
                                // Add any other information you want to display
                            } else {
                                echo "<p>No additional information available.</p>";
                            }
                            ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <h6>Attendance</h6>
                                    <!-- Attendance data -->
                                    <canvas id="attendanceChart" class="small-chart"></canvas>
                                </div>
                                <div class="col-md-6">
                                    <h6>Salaries</h6>
                                    <!-- Salary data -->
                                    <canvas id="salaryChart" class="small-chart"></canvas>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h6>Trainings</h6>
                                    <!-- Training data -->
                                    <canvas id="trainingChart" class="small-chart"></canvas>
                                </div>
                                <div class="col-md-6">
                                    <h6>Vacations</h6>
                                    <!-- Vacation data -->
                                    <canvas id="vacationChart" class="small-chart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <footer class="bg-dark text-white text-center py-3 mt-5">
        <marquee> Welcome User  - - - Enjoy your stay &#x1F600;</marquee>
    </footer>

    <!-- Edit Profile Modal -->
    <div class="modal fade" id="editProfileModal" tabindex="-1" aria-labelledby="editProfileModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editProfileModalLabel">Edit Profile</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="profile_update.php" method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="profile_image">Profile Image</label>
                            <input type="file" class="form-control" id="profile_image" name="profile_image">
                        </div>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($user_name); ?>">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user_email); ?>">
                        </div>
                        <div class="form-group">
                            <label for="address">Address</label>
                            <input type="text" class="form-control" id="address" name="address" value="<?php echo htmlspecialchars($employee_address); ?>">
                        </div>
                        <div class="form-group">
                            <label for="mobile">Mobile</label>
                            <input type="text" class="form-control" id="mobile" name="mobile" value="<?php echo htmlspecialchars($employee_mobile); ?>">
                        </div>
                        <hr>
                        <h5>Change Password</h5>
                        <div class="form-group">
                            <label for="old_password">Old Password</label>
                            <input type="password" class="form-control" id="old_password" name="old_password">
                        </div>
                        <div class="form-group">
                            <label for="new_password">New Password</label>
                            <input type="password" class="form-control" id="new_password" name="new_password">
                        </div>
                        <div class="form-group">
                            <label for="confirm_password">Confirm New Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.3/dist/Chart.min.js"></script>
    <script>
        var attendanceCtx = document.getElementById('attendanceChart').getContext('2d');
        var attendanceChart = new Chart(attendanceCtx, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Attendance',
                    data: [12, 19, 3, 5, 2, 3],
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        var salaryCtx = document.getElementById('salaryChart').getContext('2d');
        var salaryChart = new Chart(salaryCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Salaries',
                    data: [1200, 1900, 3000, 5000, 2000, 3000],
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        var trainingCtx = document.getElementById('trainingChart').getContext('2d');
        var trainingChart = new Chart(trainingCtx, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Trainings',
                    data: [5, 10, 15, 20, 25, 30],
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        var vacationCtx = document.getElementById('vacationChart').getContext('2d');
        var vacationChart = new Chart(vacationCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Vacations',
                    data: [2, 3, 5, 8, 12, 15],
                    backgroundColor: 'rgba(153, 102, 255, 0.2)',
                    borderColor: 'rgba(153, 102, 255, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
