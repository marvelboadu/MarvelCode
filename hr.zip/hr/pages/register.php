<?php
// Include database connection (not needed if included elsewhere)
include '../includes/db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect input data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $address = $_POST['address'];
    $mobile = $_POST['mobile'];

    // Check if passwords match
    if ($password != $confirm_password) {
        echo "Passwords do not match!";
        exit();
    }

    // Insert data into the employee table
    $query_employee = "INSERT INTO employee (employee_name, employee_email, employee_password, employee_address, employee_mobile) VALUES (?, ?, ?, ?, ?)";
    $stmt_employee = $conn->prepare($query_employee);
    $stmt_employee->execute([$name, $email, $password, $address, $mobile]);

    // Insert data into the users table
    $query_users = "INSERT INTO users (name, email, password, address, mobile) VALUES (?, ?, ?, ?, ?)";
    $stmt_users = $conn->prepare($query_users);
    $stmt_users->execute([$name, $email, $password, $address, $mobile]);

    // Check if both inserts were successful
    if ($stmt_employee && $stmt_users) {
        echo "Registration successful!";
        header("Location: ../Employee/profile.php");
        exit();
    } else {
        echo "Error in registration. Please try again.";
    }
}
?>
