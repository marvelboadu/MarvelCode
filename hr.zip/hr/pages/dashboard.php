<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
include '../includes/db_connect.php';

// Sample queries to get counts for each section
$query_employee = $conn->query("SELECT COUNT(*) AS count FROM employee");
$query_department = $conn->query("SELECT COUNT(*) AS count FROM departments");
$query_leave = $conn->query("SELECT COUNT(*) AS count FROM leave_applications");
$query_training = $conn->query("SELECT COUNT(*) AS count FROM trainings");
$query_salary = $conn->query("SELECT COUNT(*) AS count FROM salaries");
$query_attendance = $conn->query("SELECT COUNT(*) AS count FROM attendance");
$query_evaluation = $conn->query("SELECT COUNT(*) AS count FROM evaluation");

// Fetch counts
$employee_count = $query_employee->fetch(PDO::FETCH_ASSOC)['count'];
$department_count = $query_department->fetch(PDO::FETCH_ASSOC)['count'];
$leave_count = $query_leave->fetch(PDO::FETCH_ASSOC)['count'];
$training_count = $query_training->fetch(PDO::FETCH_ASSOC)['count'];
$salary_count = $query_salary->fetch(PDO::FETCH_ASSOC)['count'];
$attendance_count = $query_attendance->fetch(PDO::FETCH_ASSOC)['count'];
$evaluation_count = $query_evaluation->fetch(PDO::FETCH_ASSOC)['count'];

// Example data for charts (you can customize this with your actual data)
$chartData = [
    'labels' => ['Employees', 'Departments', 'Leave Applications', 'Trainings', 'Salaries', 'Attendance', 'Evaluations'],
    'data' => [
        $employee_count,
        $department_count,
        $leave_count,
        $training_count,
        $salary_count,
        $attendance_count,
        $evaluation_count
    ]
];
$chartDataJSON = json_encode($chartData);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 250px;
            background: #343a40;
            color: #fff;
            padding: 15px;
        }
        .sidebar a {
            color: #fff;
            text-decoration: none;
            display: block;
            padding: 10px;
        }
        .sidebar a:hover {
            background: #495057;
        }
        .main-content {
            flex: 1;
            padding: 20px;
        }
        .card-title {
            font-size: 1.25rem;
        }
        .card-text {
            font-size: 1rem;
        }
    </style>
</head>
<body>
<div class="sidebar">
    <h3>Admin Dashboard</h3>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="employees/list_employees.php"><i class="fas fa-users"></i> Employees</a>
    <a href="departments/list_departments.php"><i class="fas fa-building"></i> Departments</a>
    <a href="leave_applications/list_leave_applications.php"><i class="fas fa-file-alt"></i> Leave Applications</a>
    <a href="trainings/list_trainings.php"><i class="fas fa-chalkboard-teacher"></i> Trainings</a>
    <a href="salaries/list_salaries.php"><i class="fas fa-dollar-sign"></i> Salaries</a>
    <a href="attendance/list_attendance.php"><i class="fas fa-calendar-check"></i> Attendance</a>
    <a href="evaluations/list_evaluations.php"><i class="fas fa-clipboard"></i> Evaluations</a>
    <a href="vacations/list_vacations.php"><i class="fas fa-plane"></i> Vacations</a>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>
<div class="main-content">
    <h1 class="mb-4"> Admin Dashboard</h1>
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Employees</h5>
                    <p class="card-text">Total: <?php echo $employee_count; ?></p>
                    <a href="employees/list_employees.php" class="btn btn-primary">View Employees</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Departments</h5>
                    <p class="card-text">Total: <?php echo $department_count; ?></p>
                    <a href="departments/list_departments.php" class="btn btn-primary">View Departments</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Leave Applications</h5>
                    <p class="card-text">Total: <?php echo $leave_count; ?></p>
                    <a href="leave_applications/list_leave_applications.php" class="btn btn-primary">View Leave Applications</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Trainings</h5>
                    <p class="card-text">Total: <?php echo $training_count; ?></p>
                    <a href="trainings/list_trainings.php" class="btn btn-primary">View Trainings</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Salaries</h5>
                    <p class="card-text">Total: <?php echo $salary_count; ?></p>
                    <a href="salaries/list_salaries.php" class="btn btn-primary">View Salaries</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Attendance</h5>
                    <p class="card-text">Total: <?php echo $attendance_count; ?></p>
                    <a href="attendance/list_attendance.php" class="btn btn-primary">View Attendance</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Evaluations</h5>
                    <p class="card-text">Total: <?php echo $evaluation_count; ?></p>
                    <a href="evaluations/list_evaluations.php" class="btn btn-primary">View Evaluations</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Vacations</h5>
                    <p class="card-text">Total: <?php echo isset($vacation_count) ? $vacation_count : 'N/A'; ?></p>
                    <a href="vacations/list_vacations.php" class="btn btn-primary">View Vacations</a>
                </div>
            </div>
        </div>
    </div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>
</html>
