<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}
include '../../includes/db_connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave Applications - HRMS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-12">
            <h4>Leave Applications</h4>
            <a href="../dashboard.php" class="btn btn-secondary mb-3">Back to Dashboard</a>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Employee ID</th>
                        <th>From Date</th>
                        <th>To Date</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT * FROM leave_applications";
                    $stmt = $conn->prepare($sql);
                    $stmt->execute();
                    $rowCount = $stmt->rowCount();
                    if ($rowCount > 0) {
                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            echo "<tr>
                                    <td>{$row['leave_id']}</td>
                                    <td>{$row['employee_id']}</td>
                                    <td>{$row['leave_from_date']}</td>
                                    <td>{$row['leave_to_date']}</td>
                                    <td>{$row['leave_type']}</td>
                                    <td>{$row['leave_status']}</td>
                                    <td>
                                        <a href='edit_leave_application.php?id={$row['leave_id']}' class='btn btn-primary'>Edit</a>
                                        <a href='delete_leave_application.php?id={$row['leave_id']}' class='btn btn-danger'>Delete</a>
                                    </td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='7' class='text-center'>No records found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
            <a href="add_leave_application.php" class="btn btn-success">Add New Leave Application</a>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
