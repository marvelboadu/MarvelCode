<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <title>Edit Profile</title>


    
</head>
<body>

    <div class="row col-md-8 border rounded mx-auto mx-5 mt-5 p-1 shadow-lg mt-4">

        <div class=" col-md-4 text-center">
        <img src="images/no-image.jpg" alt="" class="js-image img-fluid rounded" style="width:180px; height:180px; object-fit:cover; " >


                <div class="mb-3">
                <label for="formFile" class="form-label">Select new image</label>
                <input onchange="display_image(this.files[0])" class="form-control" type="file" id="formFile">
                </div>



        </div>


        <div class=" col-md-8">
            <table class="table table-striped">
                
                    <div class="h2">Edit Profile</div>
                    <tr><th colspan="2">User Details:</th> </tr>

                    <tr><th><i class="bi bi-person"></i>Name:</th> 
                    <td>
                        <input type="text" class="form-control" name="fullname" placeholder="name">
                    </td></tr>

                    <tr><th><i class="bi bi-envelope"></i>Email</th> 
                    <td>
                    <input type="email" class="form-control" name="email" placeholder="name@example.com">

                    </td></tr>

                    <tr><th><i class="bi bi-geo-fill"></i>Address</th> 
                    <td>
                    <input type="text" class="form-control" name="address" placeholder="Address">

                    </td></tr>


                    <tr><th><i class="bi bi-phone"></i>Mobile</th> 
                    <td>
                    <input type="telephone" class="form-control" name="mobile" placeholder="mobile number">

                    </td></tr>


            
            </table>
            <div class="p-2">
            <button class="btn btn-primary m-1">
                Save 
            </button>

            <a href="profile-index.php">
            <button type="button" class="btn btn-danger m-1">
                Cancel
            </button>
            </a>
        </div>


    </div>

    







<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</body>
</html>

<script>
    function display_image(file)
    {
        var img =document.querySelector(".js-image");
        img.src = URL.createObjectURL(file);
    }

</script>