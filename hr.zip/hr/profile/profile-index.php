<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <title>Profile</title>
</head>
<body>

<div class="row col-md-8 border rounded mx-auto mx-5 mt-5 p-1 shadow-lg">

<div class="col-md-4 text-center mt-4">
<img src="images/user.jpg" alt="" class="img-fluid rounded" style="width:180px; height:180px; object-fit:cover; " >

<div>
<a href="profile-edit.php">
        <button class="btn btn-primary m-1">
            Edit
        </button>
    </a>
    <button class="btn btn-danger m-1">
        Delete
    </button>
</div>
</div>
<div class="col-md-8">
    <table class="table table-striped">
            <div class="h2">User Profile</div>
            <tr><th colspan="2">User Details:</th> </tr>

            <tr><th><i class="bi bi-person"></i>Name:</th> <td>Marvellous Boadu</td></tr>
            <tr><th><i class="bi bi-envelope"></i>Email</th> <td>marvboadu@gmail.com</td></tr>
            <tr><th><i class="bi bi-geo-fill"></i>Address</th> <td>Medie</td></tr>
            <tr><th><i class="bi bi-phone"></i>Mobile</th> <td>0549786705</td></tr>


    
    </table>
</div>

</div>


    







<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</body>
</html>