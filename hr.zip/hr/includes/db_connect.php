<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hr";

// Choose database extension
$use_pdo = true; // Set to false if you want to use MySQLi

if ($use_pdo) {
    // PDO connection
    try {
        $db_conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $db_conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $db_conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false); // Disable prepared statement emulation
        $conn = $db_conn; // Assign to $conn for consistency
    } catch(PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
        exit();
    }
} else {
    // MySQLi connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $conn->set_charset("utf8"); // Adjust charset as per your database configuration
    $db_conn = $conn; // Assign to $db_conn for consistency
}
?>
