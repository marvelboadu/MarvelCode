<html>
  <head>
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="" />
    <link
      rel="stylesheet"
      as="style"
      onload="this.rel='stylesheet'"
      href="https://fonts.googleapis.com/css2?display=swap&amp;family=Noto+Sans%3Awght%40400%3B500%3B700%3B900&amp;family=Work+Sans%3Awght%40400%3B500%3B700%3B900"
    />

    <title>Galileo Design</title>
    <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64," />

    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  </head>
  <body>
    <div class="relative flex size-full min-h-screen flex-col bg-white group/design-root overflow-x-hidden" style='font-family: "Work Sans", "Noto Sans", sans-serif;'>
      <div class="layout-container flex h-full grow flex-col">
        <div class="gap-1 px-6 flex flex-1 justify-center py-5">
          <div class="layout-content-container flex flex-col w-80">
            <div class="flex h-full min-h-[700px] flex-col justify-between bg-white p-4">
              <div class="flex flex-col gap-4">
                <div class="flex flex-col gap-2">
                  <div class="flex items-center gap-3 px-3 py-2 rounded-xl bg-[#f0f2f4]">
                    <div class="text-[#111418]" data-icon="House" data-size="24px" data-weight="fill">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                        <path
                          d="M224,115.55V208a16,16,0,0,1-16,16H168a16,16,0,0,1-16-16V168a8,8,0,0,0-8-8H112a8,8,0,0,0-8,8v40a16,16,0,0,1-16,16H48a16,16,0,0,1-16-16V115.55a16,16,0,0,1,5.17-11.78l80-75.48.11-.11a16,16,0,0,1,21.53,0,1.14,1.14,0,0,0,.11.11l80,75.48A16,16,0,0,1,224,115.55Z"
                        ></path>
                      </svg>
                    </div>
                    <p class="text-[#111418] text-sm font-medium leading-normal">Dashboard</p>
                  </div>
                  <div class="flex items-center gap-3 px-3 py-2">
                    <div class="text-[#111418]" data-icon="UsersThree" data-size="24px" data-weight="regular">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                        <path
                          d="M244.8,150.4a8,8,0,0,1-11.2-1.6A51.6,51.6,0,0,0,192,128a8,8,0,0,1-7.37-4.89,8,8,0,0,1,0-6.22A8,8,0,0,1,192,112a24,24,0,1,0-23.24-30,8,8,0,1,1-15.5-4A40,40,0,1,1,219,117.51a67.94,67.94,0,0,1,27.43,21.68A8,8,0,0,1,244.8,150.4ZM190.92,212a8,8,0,1,1-13.84,8,57,57,0,0,0-98.16,0,8,8,0,1,1-13.84-8,72.06,72.06,0,0,1,33.74-29.92,48,48,0,1,1,58.36,0A72.06,72.06,0,0,1,190.92,212ZM128,176a32,32,0,1,0-32-32A32,32,0,0,0,128,176ZM72,120a8,8,0,0,0-8-8A24,24,0,1,1,87.24,82a8,8,0,1,0,15.5-4A40,40,0,1,0,37,117.51,67.94,67.94,0,0,0,9.6,139.19a8,8,0,1,0,12.8,9.61A51.6,51.6,0,0,1,64,128,8,8,0,0,0,72,120Z"
                        ></path>
                      </svg>
                    </div>
                    <p class="text-[#111418] text-sm font-medium leading-normal">Employees</p>
                  </div>
                  <div class="flex items-center gap-3 px-3 py-2">
                    <div class="text-[#111418]" data-icon="Clock" data-size="24px" data-weight="regular">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                        <path
                          d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm64-88a8,8,0,0,1-8,8H128a8,8,0,0,1-8-8V72a8,8,0,0,1,16,0v48h48A8,8,0,0,1,192,128Z"
                        ></path>
                      </svg>
                    </div>
                    <p class="text-[#111418] text-sm font-medium leading-normal">Time Off</p>
                  </div>
                  <div class="flex items-center gap-3 px-3 py-2">
                    <div class="text-[#111418]" data-icon="File" data-size="24px" data-weight="regular">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                        <path
                          d="M213.66,82.34l-56-56A8,8,0,0,0,152,24H56A16,16,0,0,0,40,40V216a16,16,0,0,0,16,16H200a16,16,0,0,0,16-16V88A8,8,0,0,0,213.66,82.34ZM160,51.31,188.69,80H160ZM200,216H56V40h88V88a8,8,0,0,0,8,8h48V216Z"
                        ></path>
                      </svg>
                    </div>
                    <p class="text-[#111418] text-sm font-medium leading-normal">Reports</p>
                  </div>
                  <div class="flex items-center gap-3 px-3 py-2">
                    <div class="text-[#111418]" data-icon="FileText" data-size="24px" data-weight="regular">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                        <path
                          d="M213.66,82.34l-56-56A8,8,0,0,0,152,24H56A16,16,0,0,0,40,40V216a16,16,0,0,0,16,16H200a16,16,0,0,0,16-16V88A8,8,0,0,0,213.66,82.34ZM160,51.31,188.69,80H160ZM200,216H56V40h88V88a8,8,0,0,0,8,8h48V216Zm-32-80a8,8,0,0,1-8,8H96a8,8,0,0,1,0-16h64A8,8,0,0,1,168,136Zm0,32a8,8,0,0,1-8,8H96a8,8,0,0,1,0-16h64A8,8,0,0,1,168,168Z"
                        ></path>
                      </svg>
                    </div>
                    <p class="text-[#111418] text-sm font-medium leading-normal">Documents</p>
                  </div>
                  <div class="flex items-center gap-3 px-3 py-2">
                    <div class="text-[#111418]" data-icon="WifiSlash" data-size="24px" data-weight="regular">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                        <path
                          d="M213.92,210.62a8,8,0,1,1-11.84,10.76l-52-57.15a60,60,0,0,0-57.41,7.24,8,8,0,1,1-9.42-12.93A75.43,75.43,0,0,1,128,144c1.28,0,2.55,0,3.82.1L104.9,114.49A108,108,0,0,0,61,135.31,8,8,0,0,1,49.73,134,8,8,0,0,1,51,122.77a124.27,124.27,0,0,1,41.71-21.66L69.37,75.4a155.43,155.43,0,0,0-40.29,24A8,8,0,0,1,18.92,87,171.87,171.87,0,0,1,58,62.86L42.08,45.38A8,8,0,1,1,53.92,34.62ZM128,192a12,12,0,1,0,12,12A12,12,0,0,0,128,192ZM237.08,87A172.3,172.3,0,0,0,106,49.4a8,8,0,1,0,2,15.87A158.33,158.33,0,0,1,128,64a156.25,156.25,0,0,1,98.92,35.37A8,8,0,0,0,237.08,87ZM195,135.31a8,8,0,0,0,11.24-1.3,8,8,0,0,0-1.3-11.24,124.25,124.25,0,0,0-51.73-24.2A8,8,0,1,0,150,114.24,108.12,108.12,0,0,1,195,135.31Z"
                        ></path>
                      </svg>
                    </div>
                    <p class="text-[#111418] text-sm font-medium leading-normal">Settings</p>
                  </div>
                </div>
              </div>
              <div class="flex flex-col gap-1">
                <div class="flex items-center gap-3 px-3 py-2">
                  <div class="text-[#111418]" data-icon="Question" data-size="24px" data-weight="regular">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                      <path
                        d="M140,180a12,12,0,1,1-12-12A12,12,0,0,1,140,180ZM128,72c-22.06,0-40,16.15-40,36v4a8,8,0,0,0,16,0v-4c0-11,10.77-20,24-20s24,9,24,20-10.77,20-24,20a8,8,0,0,0-8,8v8a8,8,0,0,0,16,0v-.72c18.24-3.35,32-17.9,32-35.28C168,88.15,150.06,72,128,72Zm104,56A104,104,0,1,1,128,24,104.11,104.11,0,0,1,232,128Zm-16,0a88,88,0,1,0-88,88A88.1,88.1,0,0,0,216,128Z"
                      ></path>
                    </svg>
                  </div>
                  <p class="text-[#111418] text-sm font-medium leading-normal">Help</p>
                </div>
                <div class="flex items-center gap-3 px-3 py-2">
                  <div class="text-[#111418]" data-icon="Megaphone" data-size="24px" data-weight="regular">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                      <path
                        d="M240,120a48.05,48.05,0,0,0-48-48H152.2c-2.91-.17-53.62-3.74-101.91-44.24A16,16,0,0,0,24,40V200a16,16,0,0,0,26.29,12.25c37.77-31.68,77-40.76,93.71-43.3v31.72A16,16,0,0,0,151.12,214l11,7.33A16,16,0,0,0,186.5,212l11.77-44.36A48.07,48.07,0,0,0,240,120ZM40,199.93V40h0c42.81,35.91,86.63,45,104,47.24v65.48C126.65,155,82.84,164.07,40,199.93Zm131,8,0,.11-11-7.33V168h21.6ZM192,152H160V88h32a32,32,0,1,1,0,64Z"
                      ></path>
                    </svg>
                  </div>
                  <p class="text-[#111418] text-sm font-medium leading-normal">Feedback</p>
                </div>
              </div>
            </div>
          </div>
          <div class="layout-content-container flex flex-col max-w-[960px] flex-1">
            <div class="flex flex-wrap justify-between gap-3 p-4">
              <div class="flex min-w-72 flex-col gap-3">
                <p class="text-[#111418] tracking-light text-[32px] font-bold leading-tight">Good morning, Chris</p>
                <p class="text-[#637588] text-sm font-normal leading-normal">Here's what's happening with your team</p>
              </div>
            </div>
            <div class="p-4 @container">
              <div class="flex flex-1 flex-col items-start justify-between gap-4 rounded-xl border border-[#dce0e5] bg-white p-5 @[480px]:flex-row @[480px]:items-center">
                <div class="flex flex-col gap-1">
                  <p class="text-[#111418] text-base font-bold leading-tight">You're all set for payroll</p>
                  <p class="text-[#637588] text-base font-normal leading-normal">No outstanding requests</p>
                </div>
                <a class="text-sm font-bold leading-normal tracking-[0.015em] flex gap-2 text-[#111418]" href="#">
                  View details
                  <div class="text-[#111418]" data-icon="ArrowRight" data-size="20px" data-weight="regular">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" fill="currentColor" viewBox="0 0 256 256">
                      <path
                        d="M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"
                      ></path>
                    </svg>
                  </div>
                </a>
              </div>
            </div>
            <h2 class="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Quick actions</h2>
            <div class="flex gap-3 p-3 overflow-x-hidden">
              <div class="flex h-8 shrink-0 items-center justify-center gap-x-2 rounded-xl bg-[#f0f2f4] pl-4 pr-4">
                <p class="text-[#111418] text-sm font-medium leading-normal">Add employee</p>
              </div>
              <div class="flex h-8 shrink-0 items-center justify-center gap-x-2 rounded-xl bg-[#f0f2f4] pl-4 pr-4">
                <p class="text-[#111418] text-sm font-medium leading-normal">Run payroll</p>
              </div>
              <div class="flex h-8 shrink-0 items-center justify-center gap-x-2 rounded-xl bg-[#f0f2f4] pl-4 pr-4">
                <p class="text-[#111418] text-sm font-medium leading-normal">Approve time off</p>
              </div>
              <div class="flex h-8 shrink-0 items-center justify-center gap-x-2 rounded-xl bg-[#f0f2f4] pl-4 pr-4">
                <p class="text-[#111418] text-sm font-medium leading-normal">Upload document</p>
              </div>
            </div>
            <h2 class="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Time off requests</h2>
            <div class="flex items-center gap-4 bg-white px-4 min-h-[72px] py-2 justify-between">
              <div class="flex items-center gap-4">
                <div
                  class="bg-center bg-no-repeat aspect-square bg-cover rounded-full h-14 w-fit"
                  style='background-image: url("https://cdn.usegalileo.ai/stability/26ffe6cb-78fe-473a-a64b-a14825a4abc4.png");'
                ></div>
                <div class="flex flex-col justify-center">
                  <p class="text-[#111418] text-base font-medium leading-normal line-clamp-1">Vacation - Chris</p>
                  <p class="text-[#637588] text-sm font-normal leading-normal line-clamp-2">June 1st, 2022 - June 10th, 2022</p>
                </div>
              </div>
              <div class="shrink-0">
                <button
                  class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-8 px-4 bg-[#f0f2f4] text-[#111418] text-sm font-medium leading-normal w-fit"
                >
                  <span class="truncate">Approve</span>
                </button>
              </div>
            </div>
            <div class="flex items-center gap-4 bg-white px-4 min-h-[72px] py-2 justify-between">
              <div class="flex items-center gap-4">
                <div
                  class="bg-center bg-no-repeat aspect-square bg-cover rounded-full h-14 w-fit"
                  style='background-image: url("https://cdn.usegalileo.ai/stability/c6e07870-e84f-4091-af90-1d605b3c3f4e.png");'
                ></div>
                <div class="flex flex-col justify-center">
                  <p class="text-[#111418] text-base font-medium leading-normal line-clamp-1">Sick Leave - Sarah</p>
                  <p class="text-[#637588] text-sm font-normal leading-normal line-clamp-2">June 15th, 2022</p>
                </div>
              </div>
              <div class="shrink-0">
                <button
                  class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-8 px-4 bg-[#f0f2f4] text-[#111418] text-sm font-medium leading-normal w-fit"
                >
                  <span class="truncate">Approve</span>
                </button>
              </div>
            </div>
            <div class="flex items-center gap-4 bg-white px-4 min-h-[72px] py-2 justify-between">
              <div class="flex items-center gap-4">
                <div
                  class="bg-center bg-no-repeat aspect-square bg-cover rounded-full h-14 w-fit"
                  style='background-image: url("https://cdn.usegalileo.ai/stability/ebb034da-d661-4b7f-8250-e75bd1cc739a.png");'
                ></div>
                <div class="flex flex-col justify-center">
                  <p class="text-[#111418] text-base font-medium leading-normal line-clamp-1">Personal Time - Alex</p>
                  <p class="text-[#637588] text-sm font-normal leading-normal line-clamp-2">June 20th, 2022 - June 25th, 2022</p>
                </div>
              </div>
              <div class="shrink-0">
                <button
                  class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-8 px-4 bg-[#f0f2f4] text-[#111418] text-sm font-medium leading-normal w-fit"
                >
                  <span class="truncate">Approve</span>
                </button>
              </div>
            </div>
            <div class="flex items-center gap-4 bg-white px-4 min-h-[72px] py-2 justify-between">
              <div class="flex items-center gap-4">
                <div
                  class="bg-center bg-no-repeat aspect-square bg-cover rounded-full h-14 w-fit"
                  style='background-image: url("https://cdn.usegalileo.ai/stability/90ffce70-0afa-456c-b2ef-85e1df606ade.png");'
                ></div>
                <div class="flex flex-col justify-center">
                  <p class="text-[#111418] text-base font-medium leading-normal line-clamp-1">Maternity Leave - Jessica</p>
                  <p class="text-[#637588] text-sm font-normal leading-normal line-clamp-2">June 5th, 2022 - June 15th, 2022</p>
                </div>
              </div>
              <div class="shrink-0">
                <button
                  class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-8 px-4 bg-[#f0f2f4] text-[#111418] text-sm font-medium leading-normal w-fit"
                >
                  <span class="truncate">Approve</span>
                </button>
              </div>
            </div>
            <h2 class="text-[#111418] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Company analytics</h2>
            <div class="pb-3">
              <div class="flex border-b border-[#dce0e5] px-4 justify-between">
                <a class="flex flex-col items-center justify-center border-b-[3px] border-b-[#111418] text-[#111418] pb-[13px] pt-4 flex-1" href="#">
                  <p class="text-[#111418] text-sm font-bold leading-normal tracking-[0.015em]">This month</p>
                </a>
                <a class="flex flex-col items-center justify-center border-b-[3px] border-b-transparent text-[#637588] pb-[13px] pt-4 flex-1" href="#">
                  <p class="text-[#637588] text-sm font-bold leading-normal tracking-[0.015em]">Last month</p>
                </a>
                <a class="flex flex-col items-center justify-center border-b-[3px] border-b-transparent text-[#637588] pb-[13px] pt-4 flex-1" href="#">
                  <p class="text-[#637588] text-sm font-bold leading-normal tracking-[0.015em]">Last 3 months</p>
                </a>
              </div>
            </div>
            <div class="flex flex-wrap gap-4 px-4 py-6">
              <div class="flex min-w-72 flex-1 flex-col gap-2 rounded-xl border border-[#dce0e5] p-6">
                <p class="text-[#111418] text-base font-medium leading-normal">New hires</p>
                <div class="flex min-h-[180px] flex-1 flex-col gap-8 py-4">
                  <svg width="100%" height="148" viewBox="-3 0 478 150" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none">
                    <path
                      d="M0 109C18.1538 109 18.1538 21 36.3077 21C54.4615 21 54.4615 41 72.6154 41C90.7692 41 90.7692 93 108.923 93C127.077 93 127.077 33 145.231 33C163.385 33 163.385 101 181.538 101C199.692 101 199.692 61 217.846 61C236 61 236 45 254.154 45C272.308 45 272.308 121 290.462 121C308.615 121 308.615 149 326.769 149C344.923 149 344.923 1 363.077 1C381.231 1 381.231 81 399.385 81C417.538 81 417.538 129 435.692 129C453.846 129 453.846 25 472 25V149H326.769H0V109Z"
                      fill="url(#paint0_linear_1131_5935)"
                    ></path>
                    <path
                      d="M0 109C18.1538 109 18.1538 21 36.3077 21C54.4615 21 54.4615 41 72.6154 41C90.7692 41 90.7692 93 108.923 93C127.077 93 127.077 33 145.231 33C163.385 33 163.385 101 181.538 101C199.692 101 199.692 61 217.846 61C236 61 236 45 254.154 45C272.308 45 272.308 121 290.462 121C308.615 121 308.615 149 326.769 149C344.923 149 344.923 1 363.077 1C381.231 1 381.231 81 399.385 81C417.538 81 417.538 129 435.692 129C453.846 129 453.846 25 472 25"
                      stroke="#637588"
                      stroke-width="3"
                      stroke-linecap="round"
                    ></path>
                    <defs>
                      <linearGradient id="paint0_linear_1131_5935" x1="236" y1="1" x2="236" y2="149" gradientUnits="userSpaceOnUse">
                        <stop stop-color="#f0f2f4"></stop>
                        <stop offset="1" stop-color="#f0f2f4" stop-opacity="0"></stop>
                      </linearGradient>
                    </defs>
                  </svg>
                  <div class="flex justify-around">
                    <p class="text-[#637588] text-[13px] font-bold leading-normal tracking-[0.015em]">Jan</p>
                    <p class="text-[#637588] text-[13px] font-bold leading-normal tracking-[0.015em]">Feb</p>
                    <p class="text-[#637588] text-[13px] font-bold leading-normal tracking-[0.015em]">Mar</p>
                    <p class="text-[#637588] text-[13px] font-bold leading-normal tracking-[0.015em]">Apr</p>
                    <p class="text-[#637588] text-[13px] font-bold leading-normal tracking-[0.015em]">May</p>
                    <p class="text-[#637588] text-[13px] font-bold leading-normal tracking-[0.015em]">Jun</p>
                  </div>
                </div>
              </div>
              <div class="flex min-w-72 flex-1 flex-col gap-2 rounded-xl border border-[#dce0e5] p-6">
                <p class="text-[#111418] text-base font-medium leading-normal">Time off</p>
                <div class="grid min-h-[180px] gap-x-4 gap-y-6 grid-cols-[auto_1fr] items-center py-3">
                  <p class="text-[#637588] text-[13px] font-bold leading-normal tracking-[0.015em]">June 1st, 2022</p>
                  <div class="h-full flex-1"><div class="border-[#637588] bg-[#f0f2f4] border-r-2 h-full" style="width: 70%;"></div></div>
                  <p class="text-[#637588] text-[13px] font-bold leading-normal tracking-[0.015em]">June 2nd, 2022</p>
                  <div class="h-full flex-1"><div class="border-[#637588] bg-[#f0f2f4] border-r-2 h-full" style="width: 40%;"></div></div>
                  <p class="text-[#637588] text-[13px] font-bold leading-normal tracking-[0.015em]">June 3rd, 2022</p>
                  <div class="h-full flex-1"><div class="border-[#637588] bg-[#f0f2f4] border-r-2 h-full" style="width: 20%;"></div></div>
                  <p class="text-[#637588] text-[13px] font-bold leading-normal tracking-[0.015em]">June 4th, 2022</p>
                  <div class="h-full flex-1"><div class="border-[#637588] bg-[#f0f2f4] border-r-2 h-full" style="width: 90%;"></div></div>
                  <p class="text-[#637588] text-[13px] font-bold leading-normal tracking-[0.015em]">June 5th, 2022</p>
                  <div class="h-full flex-1"><div class="border-[#637588] bg-[#f0f2f4] border-r-2 h-full" style="width: 30%;"></div></div>
                  <p class="text-[#637588] text-[13px] font-bold leading-normal tracking-[0.015em]">June 6th, 2022</p>
                  <div class="h-full flex-1"><div class="border-[#637588] bg-[#f0f2f4] border-r-2 h-full" style="width: 90%;"></div></div>
                  <p class="text-[#637588] text-[13px] font-bold leading-normal tracking-[0.015em]">June 7th, 2022</p>
                  <div class="h-full flex-1"><div class="border-[#637588] bg-[#f0f2f4] border-r-2 h-full" style="width: 60%;"></div></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
